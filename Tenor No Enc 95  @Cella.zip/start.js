/*

dencrypt by https://t.me/YDqrsc

Error ? fix sendiri 

*/

console.clear();
console.log("starting...");
require("./setting/config");
process.on("uncaughtException", console.error);
const {
  default: makeWASocket,
  makeCacheableSignalKeyStore,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  generateForwardMessageContent,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  generateMessageID,
  downloadContentFromMessage,
  makeInMemoryStore,
  getContentType,
  jidDecode,
  MessageRetryMap,
  getAggregateVotesInPollMessage,
  proto,
  delay
} = require("@whiskeysockets/baileys");
const pino2 = require("pino");
const readline2 = require("readline");
const fs2 = require("fs");
const chalk2 = require("chalk");
const lodash = require("lodash");
const util2 = require("util");
const nodeFetch = require("node-fetch");
const fileType = require("file-type");
const {
  Boom
} = require("@hapi/boom");
const nodeCache = require("node-cache");
const awesomePhonenumber = require("awesome-phonenumber");
const v = new nodeCache();
const v2 = new nodeCache({
  stdTTL: 30,
  checkperiod: 20
});
const v3 = new nodeCache({
  stdTTL: 30,
  checkperiod: 20
});
const {
  color
} = require("./start/lib/color");
const {
  smsg,
  sendGmail,
  formatSize,
  isUrl,
  generateMessageTag,
  getBuffer,
  getSizeMedia,
  runtime,
  fetchJson,
  sleep
} = require("./start/lib/myfunction");
const {
  imageToWebp,
  videoToWebp,
  writeExifImg,
  writeExifVid
} = require("./start/lib/exif");
const v4 = true;
const vF = p => {
  const v5 = readline2.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  return new Promise(p2 => {
    v5.question(p, p2);
  });
};
const startLibLowdb = require("./start/lib/lowdb");
const yargsYargs = require("yargs/yargs");
const {
  Low,
  JSONFile
} = startLibLowdb;
global.opts = new Object(yargsYargs(process.argv.slice(2)).exitProcess(false).parse());
global.db = new Low(/https?:\/\//.test(opts.db || "") ? new cloudDBAdapter(opts.db) : /mongodb/.test(opts.db) ? new mongoDB(opts.db) : new JSONFile("./tmp/database.json"));
global.db = new Low(db);
global.DATABASE = global.db;
global.loadDatabase = async function f() {
  if (global.db.READ) {
    return new Promise(p3 => setInterval(function () {
      if (!global.db.READ) {
        clearInterval(this);
        p3(global.db.data == null ? global.loadDatabase() : global.db.data);
      } else {
        null;
      }
    }, 1000));
  }
  if (global.db.data !== null) {
    return;
  }
  global.db.READ = true;
  await global.db.read();
  global.db.READ = false;
  global.db.data = {
    users: {},
    chats: {},
    database: {},
    game: {},
    settings: {},
    others: {},
    sticker: {},
    ...(global.db.data || {})
  };
  global.db.chain = lodash.chain(global.db.data);
};
global.loadDatabase();
async function f2() {
  const {
    state: _0x230458,
    saveCreds: _0x2062f5
  } = await useMultiFileAuthState("session");
  const vMakeWASocket = makeWASocket({
    printQRInTerminal: !v4,
    syncFullHistory: true,
    markOnlineOnConnect: true,
    connectTimeoutMs: 60000,
    defaultQueryTimeoutMs: 0,
    keepAliveIntervalMs: 10000,
    generateHighQualityLinkPreview: true,
    patchMessageBeforeSending: p4 => {
      const v6 = !!p4.buttonsMessage || !!p4.templateMessage || !!p4.listMessage;
      if (v6) {
        p4 = {
          viewOnceMessage: {
            message: {
              messageContextInfo: {
                deviceListMetadataVersion: 2,
                deviceListMetadata: {}
              },
              ...p4
            }
          }
        };
      }
      return p4;
    },
    version: (await (await nodeFetch("https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json")).json()).version,
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    logger: pino2({
      level: "fatal"
    }),
    auth: {
      creds: _0x230458.creds,
      keys: makeCacheableSignalKeyStore(_0x230458.keys, pino2().child({
        level: "silent",
        stream: "store"
      }))
    }
  });
  if (!vMakeWASocket.authState.creds.registered) {
    const v7 = await vF("please enter your WhatsApp number, starting with 254:\n");
    const v8 = await vMakeWASocket.requestPairingCodes(v7.trim());
    console.log(chalk2.blue.bold("your pairing code: " + v8));
  }
  const vMakeInMemoryStore = makeInMemoryStore({
    logger: pino2().child({
      level: "silent",
      stream: "store"
    })
  });
  vMakeInMemoryStore.bind(vMakeWASocket.ev);
  vMakeWASocket.ev.on("messages.upsert", async p5 => {
    try {
      let v9 = p5.messages[0];
      if (!v9.message) {
        return;
      }
      v9.message = Object.keys(v9.message)[0] === "ephemeralMessage" ? v9.message.ephemeralMessage.message : v9.message;
      if (v9.key && v9.key.remoteJid === "status@broadcast") {
        return;
      }
      if (!vMakeWASocket.public && !v9.key.fromMe && p5.type === "notify") {
        return;
      }
      let vSmsg = smsg(vMakeWASocket, v9, vMakeInMemoryStore);
      require("./system")(vMakeWASocket, vSmsg, p5, v9, vMakeInMemoryStore);
    } catch (_0x411c11) {
      console.log(chalk2.yellow.bold("[ ERROR ] system.js :\n") + chalk2.redBright(util2.format(_0x411c11)));
    }
  });
  vMakeWASocket.decodeJid = p6 => {
    if (!p6) {
      return p6;
    }
    if (/:\d+@/gi.test(p6)) {
      let v10 = jidDecode(p6) || {};
      return v10.user && v10.server && v10.user + "@" + v10.server || p6;
    } else {
      return p6;
    }
  };
  vMakeWASocket.ev.on("contacts.update", p7 => {
    for (let v11 of p7) {
      let v12 = vMakeWASocket.decodeJid(v11.id);
      if (vMakeInMemoryStore && vMakeInMemoryStore.contacts) {
        vMakeInMemoryStore.contacts[v12] = {
          id: v12,
          name: v11.notify
        };
      }
    }
  });
  vMakeWASocket.sendTextWithMentions = async (p8, p9, p10, p11 = {}) => vMakeWASocket.sendMessage(p8, {
    text: p9,
    contextInfo: {
      mentionedJid: [...p9.matchAll(/@(\d{0,16})/g)].map(p12 => p12[1] + "@s.whatsapp.net")
    },
    ...p11
  }, {
    quoted: p10
  });
  vMakeWASocket.sendImageAsSticker = async (p13, p14, p15, p16 = {}) => {
    let v13 = Buffer.isBuffer(p14) ? p14 : /^data:.*?\/.*?;base64,/i.test(p14) ? Buffer.from(p14.split`, `[1], "base64") : /^https?:\/\//.test(p14) ? await await getBuffer(p14) : fs2.existsSync(p14) ? fs2.readFileSync(p14) : Buffer.alloc(0);
    let v14;
    if (p16 && (p16.packname || p16.author)) {
      v14 = await writeExifImg(v13, p16);
    } else {
      v14 = await imageToWebp(v13);
    }
    await vMakeWASocket.sendMessage(p13, {
      sticker: {
        url: v14
      },
      ...p16
    }, {
      quoted: p15
    });
    return v14;
  };
  vMakeWASocket.sendVideoAsSticker = async (p17, p18, p19, p20 = {}) => {
    let v15 = Buffer.isBuffer(p18) ? p18 : /^data:.*?\/.*?;base64,/i.test(p18) ? Buffer.from(p18.split`, `[1], "base64") : /^https?:\/\//.test(p18) ? await await getBuffer(p18) : fs2.existsSync(p18) ? fs2.readFileSync(p18) : Buffer.alloc(0);
    let v16;
    if (p20 && (p20.packname || p20.author)) {
      v16 = await writeExifVid(v15, p20);
    } else {
      v16 = await videoToWebp(v15);
    }
    await vMakeWASocket.sendMessage(p17, {
      sticker: {
        url: v16
      },
      ...p20
    }, {
      quoted: p19
    });
    return v16;
  };
  vMakeWASocket.downloadAndSaveMediaMessage = async (p21, p22, p23 = true) => {
    let v17 = p21.msg ? p21.msg : p21;
    let v18 = (p21.msg || p21).mimetype || "";
    let v19 = p21.mtype ? p21.mtype.replace(/Message/gi, "") : v18.split("/")[0];
    const v20 = await downloadContentFromMessage(v17, v19);
    let v21 = Buffer.from([]);
    for await (const v22 of v20) {
      v21 = Buffer.concat([v21, v22]);
    }
    let v23 = await fileType.fromBuffer(v21);
    let v24 = p23 ? p22 + "." + v23.ext : p22;
    await fs2.writeFileSync(v24, v21);
    return v24;
  };
  vMakeWASocket.getName = (p24, p25 = false) => {
    let v25 = vMakeWASocket.decodeJid(p24);
    p25 = vMakeWASocket.withoutContact || p25;
    let v26;
    if (v25.endsWith("@g.us")) {
      return new Promise(async p26 => {
        v26 = vMakeInMemoryStore.contacts[v25] || {};
        if (!v26.name && !v26.subject) {
          v26 = vMakeWASocket.groupMetadata(v25) || {};
        }
        p26(v26.name || v26.subject || awesomePhonenumber("+" + v25.replace("@s.whatsapp.net", "")).getNumber("international"));
      });
    } else {
      v26 = v25 === "0@s.whatsapp.net" ? {
        id: v25,
        name: "WhatsApp"
      } : v25 === vMakeWASocket.decodeJid(vMakeWASocket.user.id) ? vMakeWASocket.user : vMakeInMemoryStore.contacts[v25] || {};
    }
    return (p25 ? "" : v26.name) || v26.subject || v26.verifiedName || awesomePhonenumber("+" + p24.replace("@s.whatsapp.net", "")).getNumber("international");
  };
  vMakeWASocket.sendContact = async (p27, p28, p29 = "", p30 = {}) => {
    let v27 = [];
    for (let v28 of p28) {
      v27.push({
        displayName: await vMakeWASocket.getName(v28),
        vcard: "BEGIN:VCARD\nVERSION:3.0\nN:" + (await vMakeWASocket.getName(v28)) + "\nFN:" + (await vMakeWASocket.getName(v28)) + "\nitem1.TEL;waid=" + v28 + ":" + v28 + "\nitem1.X-ABLabel:jangan spam bang\nitem2.EMAIL;type=INTERNET: Zyurzyen\nitem2.X-ABLabel:YouTube\nitem3.URL:Zuuryzen.tech\nitem3.X-ABLabel:GitHub\nitem4.ADR:;;Indonesia;;;;\nitem4.X-ABLabel:Region\nEND:VCARD"
      });
    }
    vMakeWASocket.sendMessage(p27, {
      contacts: {
        displayName: v27.length + " Contact",
        contacts: v27
      },
      ...p30
    }, {
      quoted: p29
    });
  };
  vMakeWASocket.serializeM = p31 => smsg(vMakeWASocket, p31, vMakeInMemoryStore);
  vMakeWASocket.copyNForward = async (p32, p33, p34 = false, p35 = {}) => {
    let v29;
    if (p35.readViewOnce) {
      p33.message = p33.message?.ephemeralMessage?.message || p33.message;
      v29 = Object.keys(p33.message.viewOnceMessage.message)[0];
      delete p33.message.viewOnceMessage.message[v29].viewOnce;
      p33.message = {
        ...p33.message.viewOnceMessage.message
      };
    }
    let v30 = Object.keys(p33.message)[0];
    let v31 = await generateForwardMessageContent(p33, p34);
    let v32 = Object.keys(v31)[0];
    let v33 = {};
    if (v30 != "conversation") {
      v33 = p33.message[v30].contextInfo;
    }
    v31[v32].contextInfo = {
      ...v33,
      ...v31[v32].contextInfo
    };
    const v34 = await generateWAMessageFromContent(p32, v31, p35 ? {
      ...v31[v32],
      ...p35,
      ...(p35.contextInfo ? {
        contextInfo: {
          ...v31[v32].contextInfo,
          ...p35.contextInfo
        }
      } : {})
    } : {});
    await vMakeWASocket.relayMessage(p32, v34.message, {
      messageId: v34.key.id
    });
    return v34;
  };
  function f3(p36) {
    const v35 = Object.keys(p36);
    var v36 = !["senderKeyDistributionMessage", "messageContextInfo"].includes(v35[0]) && v35[0] || v35.length >= 3 && v35[1] !== "messageContextInfo" && v35[1] || v35[v35.length - 1] || Object.keys(p36)[0];
    return v36;
  }
  const v37 = {
    upload: vMakeWASocket.waUploadToServer
  };
  vMakeWASocket.prefa = "hah?";
  vMakeWASocket.public = global.status;
  vMakeWASocket.serializeM = p37 => smsg(client, p37, vMakeInMemoryStore);
  vMakeWASocket.ev.on("connection.update", async p38 => {
    let {
      Connecting: _0x4426ab
    } = require("./start/lib/connection/connect.js");
    _0x4426ab({
      update: p38,
      conn: vMakeWASocket,
      Boom: Boom,
      DisconnectReason: DisconnectReason,
      sleep: sleep,
      color: color,
      clientstart: f2
    });
  });
  vMakeWASocket.ev.on("group-participants.update", async p39 => {
    if (global.welcome) {
      console.log(p39);
      let v38 = await vMakeWASocket.decodeJid(vMakeWASocket.user.id);
      if (p39.participants.includes(v38)) {
        return;
      }
      try {
        let v39 = await vMakeWASocket.groupMetadata(p39.id);
        let v40 = v39.subject;
        let v41 = p39.participants;
        for (let v42 of v41) {
          let v43 = p39.author !== v42 && p39.author.length > 1;
          let v44 = v43 ? [p39.author, v42] : [v42];
          try {
            ppuser = await vMakeWASocket.profilePictureUrl(v42, "image");
          } catch {
            ppuser = "https://telegra.ph/file/de7c8230aff02d7bd1a93.jpg";
          }
          if (p39.action == "add") {
            vMakeWASocket.sendMessage(p39.id, {
              text: v43 ? "hello @" + v42.split("@")[0] + " welcome to *" + v40 + "*" : "hello @" + v42.split("@")[0] + " welcome to *" + v40 + "*",
              contextInfo: {
                mentionedJid: [...v44],
                externalAdReply: {
                  thumbnailUrl: "https://pomf2.lain.la/f/ic51evmj.jpg",
                  title: "© Welcome Message",
                  body: "",
                  renderLargerThumbnail: true,
                  sourceUrl: global.linkch,
                  mediaType: 1
                }
              }
            });
          }
          if (p39.action == "remove") {
            vMakeWASocket.sendMessage(p39.id, {
              text: v43 ? "@" + v42.split("@")[0] + " has left group *" + v40 + "*" : "@" + v42.split("@")[0] + " has left group *" + v40 + "*",
              contextInfo: {
                mentionedJid: [...v44],
                externalAdReply: {
                  thumbnailUrl: "https://pomf2.lain.la/f/7afhwfrz.jpg",
                  title: "© Leaving Message",
                  body: "",
                  renderLargerThumbnail: true,
                  sourceUrl: global.linkch,
                  mediaType: 1
                }
              }
            });
          }
          if (p39.action == "promote") {
            vMakeWASocket.sendMessage(p39.id, {
              text: "@" + p39.author.split("@")[0] + " has made @" + v42.split("@")[0] + " as admin of this group",
              contextInfo: {
                mentionedJid: [...v44],
                externalAdReply: {
                  thumbnailUrl: "https://pomf2.lain.la/f/ibiu2td5.jpg",
                  title: "© Promote Message",
                  body: "",
                  renderLargerThumbnail: true,
                  sourceUrl: global.linkch,
                  mediaType: 1
                }
              }
            });
          }
          if (p39.action == "demote") {
            vMakeWASocket.sendMessage(p39.id, {
              text: "@" + p39.author.split("@")[0] + " has removed @" + v42.split("@")[0] + " as admin of this group",
              contextInfo: {
                mentionedJid: [...v44],
                externalAdReply: {
                  thumbnailUrl: "https://pomf2.lain.la/f/papz9tat.jpg",
                  title: "© Demote Message",
                  body: "",
                  renderLargerThumbnail: true,
                  sourceUrl: global.linkch,
                  mediaType: 1
                }
              }
            });
          }
        }
      } catch (_0x237320) {
        console.log(_0x237320);
      }
    }
  });
  vMakeWASocket.sendButtonImg = async (p40, p41 = [], p42, p43, p44, p45 = "", p46 = {}) => {
    const v45 = {
      image: {
        url: p43
      },
      caption: p42,
      footer: p44,
      buttons: p41.map(p47 => ({
        buttonId: p47.id || "",
        buttonText: {
          displayText: p47.text || "Button"
        },
        type: p47.type || 1
      })),
      headerType: 1,
      viewOnce: p46.viewOnce || false
    };
    vMakeWASocket.sendMessage(p40, v45, {
      quoted: p45
    });
  };
  vMakeWASocket.sendList = async (p48, p49, p50, p51, p52 = "", p53 = {}) => {
    let vGenerateWAMessageFromContent = generateWAMessageFromContent(p48, {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            ...p53,
            body: proto.Message.InteractiveMessage.Body.create({
              text: p49
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: p50 || "puqi"
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify(p51)
              }]
            })
          })
        }
      }
    }, {
      quoted: p52
    });
    return await vMakeWASocket.relayMessage(vGenerateWAMessageFromContent.key.remoteJid, vGenerateWAMessageFromContent.message, {
      messageId: vGenerateWAMessageFromContent.key.id
    });
  };
  vMakeWASocket.sendButtonProto = async (p54, p55, p56, p57 = [], p58 = "", p59 = {}) => {
    let vGenerateWAMessageFromContent2 = generateWAMessageFromContent(p54, {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            ...p59,
            body: proto.Message.InteractiveMessage.Body.create({
              text: p55
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: p56 || "puqi"
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: p57
            })
          })
        }
      }
    }, {
      quoted: p58
    });
    return await vMakeWASocket.relayMessage(vGenerateWAMessageFromContent2.key.remoteJid, vGenerateWAMessageFromContent2.message, {
      messageId: vGenerateWAMessageFromContent2.key.id
    });
  };
  vMakeWASocket.ments = (p60 = "") => {
    if (p60.match("@")) {
      return [...p60.matchAll(/@([0-9]{5,16}|0)/g)].map(p61 => p61[1] + "@s.whatsapp.net");
    } else {
      return [];
    }
  };
  vMakeWASocket.cMod = (p62, p63, p64 = "", p65 = vMakeWASocket.user.id, p66 = {}) => {
    let v46 = Object.keys(p63.message)[0];
    let v47 = v46 === "ephemeralMessage";
    if (v47) {
      v46 = Object.keys(p63.message.ephemeralMessage.message)[0];
    }
    let v48 = v47 ? p63.message.ephemeralMessage.message : p63.message;
    let v49 = v48[v46];
    if (typeof v49 === "string") {
      v48[v46] = p64 || v49;
    } else if (v49.caption) {
      v49.caption = p64 || v49.caption;
    } else if (v49.text) {
      v49.text = p64 || v49.text;
    }
    if (typeof v49 !== "string") {
      v48[v46] = {
        ...v49,
        ...p66
      };
    }
    if (p63.key.participant) {
      p65 = p63.key.participant = p65 || p63.key.participant;
    } else if (p63.key.participant) {
      p65 = p63.key.participant = p65 || p63.key.participant;
    }
    if (p63.key.remoteJid.includes("@s.whatsapp.net")) {
      p65 = p65 || p63.key.remoteJid;
    } else if (p63.key.remoteJid.includes("@broadcast")) {
      p65 = p65 || p63.key.remoteJid;
    }
    p63.key.remoteJid = p62;
    p63.key.fromMe = p65 === vMakeWASocket.user.id;
    return proto.WebMessageInfo.fromObject(p63);
  };
  vMakeWASocket.sendText = (p67, p68, p69 = "", p70) => vMakeWASocket.sendMessage(p67, {
    text: p68,
    ...p70
  }, {
    quoted: p69
  });
  vMakeWASocket.deleteMessage = async (p71, p72) => {
    try {
      await vMakeWASocket.sendMessage(p71, {
        delete: p72
      });
      console.log("Pesan dihapus: " + p72.id);
    } catch (_0x6ccc52) {
      console.error("Gagal menghapus pesan:", _0x6ccc52);
    }
  };
  vMakeWASocket.downloadMediaMessage = async p73 => {
    let v50 = (p73.msg || p73).mimetype || "";
    let v51 = p73.mtype ? p73.mtype.replace(/Message/gi, "") : v50.split("/")[0];
    const v52 = await downloadContentFromMessage(p73, v51);
    let v53 = Buffer.from([]);
    for await (const v54 of v52) {
      v53 = Buffer.concat([v53, v54]);
    }
    return v53;
  };
  vMakeWASocket.ev.on("creds.update", _0x2062f5);
  vMakeWASocket.serializeM = p74 => smsg(vMakeWASocket, p74, vMakeInMemoryStore);
  return vMakeWASocket;
}
f2();
let v55 = require.resolve(__filename);
fs2.watchFile(v55, () => {
  fs2.unwatchFile(v55);
  console.log(chalk2.redBright("Update " + __filename));
  delete require.cache[v55];
  require(v55);
});
/*

dencrypt by https://t.me/YDqrsc

Error ? fix sendiri 

*/